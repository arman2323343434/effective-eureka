!function($) {
    (function() {
            try {
                $(function() {
                    try {
                        var e, r, t, l, a, i, n;
                        if (r = $(".macros-map"),
                            !r.length)
                            return;
                        if (a = !1,
                            l = !1,
                            t = !1,
                            e = !1,
                            r.each(function() {
                                try {
                                    if ("yandex" === $(this).data("service") && (a = !0,
                                        t = $('.macros-map[data-service="yandex"]')),
                                    "google" === $(this).data("service"))
                                        return l = !0,
                                            e = $('.macros-map[data-service="google"]')
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            }),
                            n = "//api-maps.yandex.ru/2.1/?lang=ru-RU",
                            i = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAv1x29uW3_4ZVynxnrZZW_LTedvmMGfz8&language=ru&libraries=places",
                        a && $.getScript(n, function() {
                            try {
                                if ("undefined" == typeof ymaps)
                                    return;
                                return ymaps.ready(function() {
                                    try {
                                        return t.each(function() {
                                            try {
                                                var e;
                                                return e = plp.lazy.add($(this), function(r) {
                                                    try {
                                                        var t, l, a, i, n;
                                                        return t = e.children(".map"),
                                                            l = t.data("map"),
                                                            a = _.uniqueId("map"),
                                                            t.attr("id", a),
                                                        "roadmap" === l.type && (l.type = "yandex#map"),
                                                            i = new ymaps.Map(a,{
                                                                center: l.center,
                                                                type: l.type,
                                                                zoom: l.zoom,
                                                                controls: []
                                                            }),
                                                            i.behaviors.disable(["scrollZoom"]),
                                                            n = new ymaps.GeoObject({
                                                                geometry: {
                                                                    type: "Point",
                                                                    coordinates: l.point
                                                                }
                                                            },{
                                                                draggable: !1
                                                            }),
                                                            i.geoObjects.add(n),
                                                            i.controls.add("zoomControl", {
                                                                "float": "left"
                                                            }).add("typeSelector", {
                                                                "float": "right"
                                                            })
                                                    } catch (c) {
                                                        error_handler(c, "libs_plp 6", arguments.callee)
                                                    }
                                                })
                                            } catch (r) {
                                                error_handler(r, "libs_plp 5", arguments.callee)
                                            }
                                        })
                                    } catch (e) {
                                        error_handler(e, "libs_plp 4", arguments.callee)
                                    }
                                })
                            } catch (e) {
                                error_handler(e, "libs_plp 3", arguments.callee)
                            }
                        }),
                            l)
                            return $.getScript(i, function() {
                                try {
                                    if ("undefined" == typeof google)
                                        return;
                                    return e.each(function() {
                                        try {
                                            var e;
                                            return e = plp.lazy.add($(this), function(r) {
                                                try {
                                                    var t, l, a, i, n;
                                                    return t = e.children(".map"),
                                                        l = t.data("map"),
                                                        a = _.uniqueId("map"),
                                                        t.attr("id", a),
                                                    "yandex#map" === l.type && (l.type = "roadmap"),
                                                        i = new google.maps.Map(document.getElementById(a),{
                                                            zoom: l.zoom,
                                                            center: new google.maps.LatLng(l.center[0],l.center[1]),
                                                            mapTypeId: l.type,
                                                            fullscreenControl: !1,
                                                            rotateControl: !1,
                                                            streetViewControl: !1,
                                                            scrollwheel: !1
                                                        }),
                                                        n = new google.maps.Marker({
                                                            position: new google.maps.LatLng(l.point[0],l.point[1]),
                                                            map: i,
                                                            draggable: !1
                                                        })
                                                } catch (c) {
                                                    error_handler(c, "libs_plp 9", arguments.callee)
                                                }
                                            })
                                        } catch (r) {
                                            error_handler(r, "libs_plp 8", arguments.callee)
                                        }
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 7", arguments.callee)
                                }
                            })
                    } catch (c) {
                        error_handler(c, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
    ).call(this),
        plp.l10n = function(e, r) {
            try {
                if (r = r || "",
                "ru" === plp.lang)
                    return e;
                var t = plp.l10n.dictionary.find(function(t) {
                    try {
                        return t.original === e && t.context === r
                    } catch (l) {
                        error_handler(l, "libs_plp 1", arguments.callee)
                    }
                });
                return t && t[plp.lang] ? t[plp.lang] : (console.error("No translation for ", e),
                    e)
            } catch (l) {
                error_handler(l, "libs_plp 0", arguments.callee)
            }
        }
        ,
        plp.l10n.dictionary = [{
            original: "Не удалось отправить форму!",
            context: "",
            en: "Error sending form",
            "pt-BR": "Erro ao enviar o formulário",
            es: "Error al enviar el formulario",
            "zh-CN": "发送表格出错",
            de: "Fehler beim Senden des Formulars",
            it: "Errore invio modulo",
            fr: "Erreur lors de l'envoi du formulaire",
            pl: "Nie udało się wysłać formularza",
            lt: "Nepasisekė nusiųsti formą!",
            lv: "Jūsu ziņojums netika nosūtīts!",
            bg: "Неуспешно изпращане на заявката!",
            cs: "Chyba při odesílání formuláře",
            he: "שליחת הטופס נכשלה",
            el: "Η φόρμα δε στάλθηκε",
            am: "Հայտն ուղարկված չէ, խնդրում ենք կրկին փորձել",
            ge: "ფორმა არ გაიგზავნა!",
            ro: "A apărut o eroare la trimiterea formularului",
            kz: "Нысаныңыз жіберілмеді",
            uk: "Помилка надсилання форми"
        }, {
            original: "Неправильно заполнены поля:",
            context: "",
            en: "These fields were not filled in correctly:",
            "pt-BR": "Estes campos não foram preenchidos corretamente:",
            es: "Estos campos no se han rellenado correctamente:",
            "zh-CN": "以下字段未正确填写：",
            de: "Diese Felder wurden nicht korrekt ausgefüllt:",
            it: "Questi campi non sono stati compilati correttamente:",
            fr: "Ces champs n’ont pas été renseignés correctement :",
            pl: "Te pola nie zostały poprawnie wypełnione:",
            lt: "Neteisingai užpildyti laukai:",
            lv: "Lauks nav aizpildīts vai ir aizpildīts nepareizi:",
            bg: "Грешно запълнени полета:",
            cs: "Tato pole nebyla vyplněna správně:",
            he: "השדות הבאים לא מולאו כהלכה:",
            el: "Αυτά τα πεδία δε συμπληρώθηκαν σωστά:",
            am: "Տողերը սխալ են լրացված",
            ge: "შემდეგი ველები არასწორად არის შევსებული:",
            ro: "Aceste câmpuri nu au fost completate corect:",
            kz: "Бұл өрістер дұрыс толтырылмаған:",
            uk: "Ці поля були заповнені неправильно:"
        }, {
            original: "Пожалуйста, повторите отправку через пару секунд.",
            context: "",
            en: "Please try again in a few seconds.",
            "pt-BR": "Tente novamente em alguns segundos.",
            es: "Por favor, inténtelo de nuevo dentro de unos segundos.",
            "zh-CN": "请稍后再试",
            de: "Bitte versuchen Sie es in ein paar Sekunden erneut.",
            it: "Riprova tra pochi secondi.",
            fr: "Veuillez réessayer dans quelques secondes.",
            pl: "Powtórz za parę sekund.",
            lt: "Prašome pakartoti siuntimą po keletą sekundžių.",
            lv: "Lūdzu, nosūtiet atkārtoti pēc dažām sekundēm.",
            bg: "Моля, изпратете отново заявката след няколко секунди.",
            cs: "Prosím zkuste to znovu za pár vteřin.",
            he: "נסה שוב בעוד כמה שניות.",
            el: "Προσπαθήστε ξανά σε μερικά δευτερόλεπτα.",
            am: "Տողերը սխալ են մուտքագրված: Խնդրում ենք կրկին փորձել մի քանի վարկյանից",
            ge: "გაიმეორეთ გაგზავნის",
            ro: "Vă rugăm să încercați din nou peste câteva secunde.",
            kz: "Бірнеше секундтан кейін қайталап көріңіз.",
            uk: "Будь ласка, спробуйте ще раз за кілька секунд."
        }, {
            original: "Поле «%field%» обязательно для заполнения.",
            context: "",
            en: 'The "%field%" field is required.',
            "pt-BR": 'O campo "%field%" é necessário.',
            es: "El campo %field% es obligatorio.",
            "zh-CN": "“%field%” 为必填字段。",
            de: "Das Feld „%field%“ ist ein Pflichtfeld.",
            it: "Il campo «%field%» è obbligatorio.",
            fr: "Vous devez remplir le champ « %field% ».",
            pl: 'Pole "%field%" musi być wypełnione.',
            lt: "Laukas «%field%» būtinas užpildymui.",
            lv: "Lauks «%field%» jāaizpilda obligāti.",
            bg: "Полето «%field%» е задължително за запълване.",
            cs: "Pole „%field%“ je povinné.",
            he: 'השדה "%field%" הוא שדה חובה.',
            el: "Απαιτείται πεδίο «%field%».",
            am: "Խնդրում ենք լրացրեք «%field%» տողը, այն պարտադիր է",
            ge: "ამ ველის «%field%» შევსება აუცილებელია.",
            ro: "Câmpul „%field%” este obligatoriu.",
            kz: '"%field%" өрісін толтыру қажет.',
            uk: "Поле «%field%» є обов'язковим."
        }, {
            original: "Поле «%field%» должно содержать ваш настоящий e-mail адрес.",
            context: "",
            en: 'The "%field%" field must contain your actual email address.',
            "pt-BR": 'O campo "%field%" deve conter o seu endereço de e-mail correto.',
            es: "El campo %field% debe contener su dirección de correo electrónico real.",
            "zh-CN": "“%field%” 字段必须包含真实的电子邮件地址。",
            de: "Das Feld „%field%“ muss Ihre tatsächliche E-Mail Adresse enthalten.",
            it: "Il campo «%field%» deve contenere il tuo indirizzo e-mail.",
            fr: "Le champ « %field% » doit contenir votre adresse e-mail réelle.",
            pl: 'Pole "%field%" musi zawierać Twój adres e-mail.',
            lt: "Laukas «%field%» turi būti nurodytas jūsų esamas email adresas.",
            lv: "Laukā «%field%» jābūt Jūsu īstai e-pasta adresei.",
            bg: "Полето «%field%» трябва да съдържа истинският Ви имейл адрес.",
            cs: "Pole «%field%» musí obsahovat vaši správnou e-mail adresu.",
            he: 'בשדה "%field%" עליך להזין את כתובת הדוא"ל הפעילה שלך.',
            el: "Το πεδίο «%field%» πρέπει να περιλαμβάνει την πραγματική διεύθυνση e-mail σας.",
            am: "Խնդրում ենք «%field%» տողում գրանցել Ձեր իրական էլ. փոստի հասցեն",
            ge: "ეს ველი «%field%» უნდა შეიცავდეს თქვენი ნამდვილი ელ-ფოსტის მისამართს.",
            ro: "Câmpul „%field%” trebuie să conțină adresa dvs. e-mail veridică.",
            kz: '"%field%" өрісінде сіздің нақты э-пошта мекенжайыңыз болуы тиіс.',
            uk: "Поле «%field%» повинно містити вашу справжню електронну поштову адресу."
        }, {
            original: "Поле «%field%» должно содержать правильный номер телефона.",
            context: "",
            en: 'The "%field%" field must contain your correct phone number.',
            "pt-BR": 'O campo "%field%" deve conter um número de telefone válido.',
            es: "El campo %field% debe contener su numero de teléfono correcto.",
            "zh-CN": "“%field%” 字段必须包含有效的手机号码。",
            de: "Das Feld „%field%“ muss Ihre richtige Telefonnummer enthalten.",
            it: "Il campo «%field%» deve contenere il tuo numero di telefono.",
            fr: "Le champ « %field% » doit contenir un numéro de téléphone valide.",
            pl: 'Pole "%field%" musi zawierać prawidłowy numer telefonu.',
            lt: "Laukas «%field%» turi būti teisingai nurodytas telefono numeris.",
            lv: "Laukā «%field%» jānorāda īstais telefona numurs.",
            bg: "Полето «%field%» задължително трябва да съдържа правилният Ви телефонен номер.",
            cs: "Pole «%field%» musí obsahovat vaše správné telefonní číslo.",
            he: 'בשדה "%field%" עליך להזין את מספר הטלפון המדויק שלך.',
            el: "Το πεδίο «%field%» πρέπει να περιέχει τον σωστό αριθμό τηλεφώνου.",
            am: "Խնդրում ենք «%field%» տողում գրանցել Ձեր ճիշտ հեռախոսահամարը",
            ge: "ეს ველი «%field%» უნდა შეიცავდეს რეალურად არსებულ ტელეფონის ნომერს.",
            ro: "Câmpul „%field%” trebuie să conțină numărul dvs. de telefon veridic.",
            kz: '"%field%" өрісінде дұрыс телефон нөмірі болуы тиіс.',
            uk: "Поле «%field%» повинно містити ваш правильний номер телефону."
        }, {
            original: "Поле «%field%» должно быть правильным числом.",
            context: "",
            en: 'The "%field%" field must be an actual number.',
            "pt-BR": 'O campo "%field%" deve conter um número válido.',
            es: "El campo %field% debe ser un número real.",
            "zh-CN": "“%field%” 字段必须包含有效的号码。",
            de: "Das Feld „%field%“ muss eine gültige Zahl sein.",
            it: "Il campo «%field%» deve contenere un numero.",
            fr: "Le champ « %field% » doit être un nombre valide.",
            pl: 'Pole "%field%" musi zawierać właściwy numer.',
            lt: "Laukas «%field%» turu būti nurodytas teisingas skaičius.",
            lv: "Laukā «%field%» jānorāda tikai cipari.",
            bg: "Полето «%field%» трябва да съдържа правилно изписано число.",
            cs: "Pole „%field%“ musí být skutečný počet.",
            he: 'בשדה "%field%" עליך להזין מספר אמיתי.',
            el: "Το πεδίο «%field%» πρέπει να είναι πραγματικός αριθμός.",
            am: "Խնդրում ենք «%field%» տողում գրանցել ճիշտ ամսաթիվ",
            ge: "ამ ველში «%field%» უნდა იყოს სწორი რიცხვი.",
            ro: "Câmpul „%field%” trebuie să conțină un număr real.",
            kz: '"%field%" өрісінде нақты сан болуы тиіс.',
            uk: "Поле «%field%» має бути дійсним числом."
        }, {
            original: "Товар не найден",
            context: "",
            en: "Product not found",
            "pt-BR": "Produto não encontrado",
            es: "Producto no hallado",
            "zh-CN": "未找到产品",
            de: "Produkt nicht gefunden",
            it: "Prodotto non trovato",
            fr: "Produit non trouvé",
            pl: "Nie znaleziono produktu",
            lt: "Товар не найден",
            lv: "Товар не найден",
            bg: "Товар не найден",
            cs: "Produkt nenalezen",
            he: "המוצר לא נמצא",
            el: "Το προϊόν δεν βρέθηκε",
            am: "Товар не найден",
            ge: "Товар не найден",
            ro: "Produsul nu a fost găsit",
            kz: "Өнім табылмады",
            uk: "Продукт не знайдено"
        }, {
            original: "Кнопка должна находиться в карточке товара.",
            context: "",
            en: "The button should be located on the product card.",
            "pt-BR": "O botão deve estar localizado no cartão do produto.",
            es: "El botón debería encontrarse en la tarjeta del producto.",
            "zh-CN": "按钮应该位于产品卡上。",
            de: "Die Schaltfläche sollte sich auf der Produktkarte befinden.",
            it: "Il pulsante dovrebbe trovarsi sulla scheda del prodotto.",
            fr: "Le bouton devrait se trouver sur la fiche produit.",
            pl: "Przycisk powinien znajdować się na karcie produktu.",
            lt: "Кнопка должна находиться в карточке товара.",
            lv: "Кнопка должна находиться в карточке товара.",
            bg: "Кнопка должна находиться в карточке товара.",
            cs: "Tlačítko by se mělo nacházet na kartě produktu.",
            he: "הלחצן אמור להופיע בכרטיס המוצר.",
            el: "Το κουμπί πρέπει να βρίσκεται στην καρτέλα προϊόντος.",
            am: "Кнопка должна находиться в карточке товара.",
            ge: "Кнопка должна находиться в карточке товара.",
            ro: "Butonul ar trebui să fie amplasat pe cardul produsului.",
            kz: "Түйме өнім карточкасында орналасуы тиіс.",
            uk: "Кнопка має бути розташована на картці продукту."
        }, {
            original: "Количество",
            context: "",
            en: "Quantity",
            "pt-BR": "Quantidade",
            es: "Cantidad",
            "zh-CN": "数量",
            de: "Menge",
            it: "Quantità",
            fr: "Quantité",
            pl: "Ilość",
            lt: "Количество",
            lv: "Количество",
            bg: "Количество",
            cs: "Množství",
            he: "כמות",
            el: "Ποσότητα",
            am: "Количество",
            ge: "Количество",
            ro: "Cantitate",
            kz: "Саны",
            uk: "Кількість"
        }, {
            original: "Добавлено в корзину!",
            context: "",
            en: "Added to cart!",
            "pt-BR": "Adicionado ao carrinho!",
            es: "¡Se ha añadido al carrito!",
            "zh-CN": "已加至购物车！",
            de: "Zum Warenkorb hinzugefügt!",
            it: "Aggiunto al carrello!",
            fr: "Ajouté au panier !",
            pl: "Dodano do koszyka!",
            lt: "Добавлено в корзину!",
            lv: "Добавлено в корзину!",
            bg: "Добавлено в корзину!",
            cs: "Přidáno do košíku!",
            he: "נוסף לעגלה!",
            el: "Προστέθηκε στο καλάθι!",
            am: "Добавлено в корзину!",
            ge: "Добавлено в корзину!",
            ro: "Adăugat în coș!",
            kz: "Себетке қосылды!",
            uk: "Додано до кошику!"
        }, {
            original: "ОК",
            context: "",
            en: "OK",
            "pt-BR": "OK",
            es: "Vale",
            "zh-CN": "确定",
            de: "OK",
            it: "OK",
            fr: "OK",
            pl: "OK",
            lt: "OK",
            lv: "OK",
            bg: "OK",
            cs: "OK",
            he: "אישור",
            el: "ΟΚ",
            am: "OK",
            ge: "OK",
            ro: "Ok",
            kz: "OK",
            uk: "ОК"
        }, {
            original: "Открыть корзину",
            context: "По клику появляется окошко с корзиной. То есть тут не переход на новую страницу, а показ окна.",
            en: "View cart",
            "pt-BR": "Ver carrinho",
            es: "Ver carrito",
            "zh-CN": "查看购物车",
            de: "Warenkorb anzeigen",
            it: "Guarda il carrello",
            fr: "Voir le panier",
            pl: "Wyświetl koszyk",
            lt: "Открыть корзину",
            lv: "Открыть корзину",
            bg: "Открыть корзину",
            cs: "Zobrazit košík",
            he: "הצג עגלה",
            el: "Προβολή καλαθιού",
            am: "Открыть корзину",
            ge: "Открыть корзину",
            ro: "Vizualizare coș",
            kz: "Себетті көру",
            uk: "Переглянути кошик"
        }, {
            original: "Да",
            context: "",
            en: "Yes",
            "pt-BR": "Sim",
            es: "Sí",
            "zh-CN": "是",
            de: "Ja",
            it: "Sì",
            fr: "Oui",
            pl: "Tak",
            lt: "Да",
            lv: "Да",
            bg: "Да",
            cs: "Ano",
            he: "כן",
            el: "Ναι",
            am: "Да",
            ge: "Да",
            ro: "Da",
            kz: "Иә",
            uk: "Так"
        }, {
            original: "Нет",
            context: "",
            en: "No",
            "pt-BR": "Não",
            es: "No",
            "zh-CN": "否",
            de: "Nein",
            it: "No",
            fr: "Non",
            pl: "Nie",
            lt: "Нет",
            lv: "Нет",
            bg: "Нет",
            cs: "Ne",
            he: "לא",
            el: "Όχι",
            am: "Нет",
            ge: "Нет",
            ro: "Nu",
            kz: "Жоқ",
            uk: "Ні"
        }, {
            original: "Загрузка...",
            context: "С компьютера на сервер",
            en: "Loading...",
            "pt-BR": "Carregando...",
            es: "Cargando...",
            "zh-CN": "载入中…",
            de: "Wird geladen ...",
            it: "Caricamento...",
            fr: "Chargement...",
            pl: "Ładowanie...",
            lt: "Загрузка...",
            lv: "Загрузка...",
            bg: "Загрузка...",
            cs: "Načítání...",
            he: "טוען...",
            el: "Φόρτωση...",
            am: "Загрузка...",
            ge: "Загрузка...",
            ro: "Încărcare...",
            kz: "Жүктелуде...",
            uk: "Завантаження..."
        }, {
            original: "Файл загружен",
            context: "",
            en: "File loaded",
            "pt-BR": "Arquivo carregado",
            es: "Archivo cargado",
            "zh-CN": "文件已载入",
            de: "Datei geladen",
            it: "File caricato",
            fr: "Fichier chargé",
            pl: "Załadowano plik",
            lt: "Файл загружен",
            lv: "Файл загружен",
            bg: "Файл загружен",
            cs: "Soubor načten",
            he: "הקובץ נטען",
            el: "Έγινε φόρτωση αρχείου",
            am: "Файл загружен",
            ge: "Файл загружен",
            ro: "Fișierul a fost încărcat",
            kz: "Файл жүктелді",
            uk: "Файл завантажено"
        }, {
            original: "Ошибка загрузки!",
            context: "",
            en: "Loading error",
            "pt-BR": "Erro ao carregar",
            es: "Error de carga",
            "zh-CN": "载入出错",
            de: "Fehler beim Laden",
            it: "Errore di caricamento",
            fr: "Erreur de chargement",
            pl: "Błąd podczas ładowania",
            lt: "Ошибка загрузки!",
            lv: "Ошибка загрузки!",
            bg: "Ошибка загрузки!",
            cs: "Chyba při načítání",
            he: "שגיאת טעינה",
            el: "Σφάλμα φόρτωσης",
            am: "Ошибка загрузки!",
            ge: "Ошибка загрузки!",
            ro: "Eroare la încărcare",
            kz: "Жүктеу қателігі",
            uk: "Помилка завантаження"
        }, {
            original: "Выберите файл...",
            context: "",
            en: "Select a file...",
            "pt-BR": "Selecione um arquivo...",
            es: "Seleccionar un archivo...",
            "zh-CN": "选择一个文件…",
            de: "Wählen Sie eine Datei ...",
            it: "Seleziona un file...",
            fr: "Sélectionnez un fichier...",
            pl: "Wybierz plik...",
            lt: "Выберите файл...",
            lv: "Выберите файл...",
            bg: "Выберите файл...",
            cs: "Vyber soubor...",
            he: "בחר קובץ...",
            el: "Επιλέξτε ένα αρχείο...",
            am: "Выберите файл...",
            ge: "Выберите файл...",
            ro: "Selectaţi un fişier...",
            kz: "Файлды таңдаңыз...",
            uk: "Оберіть файл..."
        }],
        function() {
            try {
                $(function() {
                    try {
                        var e, r, t, l, a, n, c, o, s, d;
                        return a = window.plp_page_id || window.plp.page_id,
                            e = window.plp_content_id || window.plp.content_id,
                            d = $.cookie("visit_id"),
                            c = 0,
                            n = 2500,
                            r = {
                                error: plp.l10n("Не удалось отправить форму!"),
                                validate: plp.l10n("Неправильно заполнены поля:"),
                                interval: plp.l10n("Пожалуйста, повторите отправку через пару секунд."),
                                required: plp.l10n("Поле «%field%» обязательно для заполнения."),
                                email: plp.l10n("Поле «%field%» должно содержать ваш настоящий e-mail адрес."),
                                phone: plp.l10n("Поле «%field%» должно содержать правильный номер телефона."),
                                number: plp.l10n("Поле «%field%» должно быть правильным числом.")
                            },
                            s = plp.l10n("Да"),
                            o = plp.l10n("Нет"),
                            t = function(e, r, t) {
                                try {
                                    var l;
                                    return "xs" === plp.screen ? (l = e,
                                    r && (l += "\n" + r),
                                        alert(l),
                                        void (t && t())) : Modernizr.cssanimations ? swal({
                                        title: e,
                                        text: r || null,
                                        type: "error"
                                    }, t) : swal({
                                        title: e,
                                        text: r || null,
                                        imageUrl: "//s.plpstatic.ru/swal/error.png"
                                    }, t)
                                } catch (a) {
                                    error_handler(a, "libs_plp 2", arguments.callee)
                                }
                            }
                            ,
                            l = function(e, r, t) {
                                try {
                                    var l;
                                    return "xs" === plp.screen ? (l = e,
                                    r && (l += "\n" + r),
                                        alert(l),
                                        void (t && t())) : Modernizr.cssanimations ? swal({
                                        title: e,
                                        text: r || null,
                                        type: "success"
                                    }, t) : swal({
                                        title: e,
                                        text: r || null,
                                        imageUrl: "//s.plpstatic.ru/swal/success.png"
                                    }, t)
                                } catch (a) {
                                    error_handler(a, "libs_plp 3", arguments.callee)
                                }
                            }
                            ,
                            _.defer(function() {
                                try {
                                    return $("form.form").each(function() {
                                        try {
                                            var p, h, u, f, m, v, b, y;
                                            return u = $(this),
                                                m = u.data("form"),
                                                v = u.closest("[data-item]").data("item") || [],
                                                b = u.closest('[data-modal="cart"]').length ? plp.cart.list : [],
                                                f = u.data("fields"),
                                                y = {
                                                    hit: {
                                                        page_id: a,
                                                        ab_id: e,
                                                        visit_id: d,
                                                        referer: document.referrer,
                                                        uri: location.pathname + location.search
                                                    },
                                                    form: m,
                                                    item: v,
                                                    items: b,
                                                    fields: f
                                                },
                                                h = u.find(".field").each(function(e) {
                                                    try {
                                                        var r, l, a;
                                                        if (r = $(this),
                                                            a = y.fields[e],
                                                        "radio-list" === a.type && r.find("input").prop("name", _.uniqueId("radio")),
                                                        "textarea" === a.type && r.find("textarea").val(function(e, r) {
                                                            try {
                                                                return $.trim(r)
                                                            } catch (t) {
                                                                error_handler(t, "libs_plp 7", arguments.callee)
                                                            }
                                                        }),
                                                        "file" === a.type)
                                                            return (l = function() {
                                                                    try {
                                                                        return r.find(":file").on("change", function() {
                                                                            try {
                                                                                var e, a;
                                                                                for (a = r.find(":file").closest(".pseudo"),
                                                                                         a.clone().insertAfter(a),
                                                                                         e = $("<form>"),
                                                                                         i = 0,
                                                                                         attributes = a[0].attributes; i < attributes.length; i++)
                                                                                    e.attr(attributes[i].name, attributes[i].value);
                                                                                return e.append(a.children()),
                                                                                    e.appendTo("body").hide(),
                                                                                    a.remove(),
                                                                                    e.ajaxSubmit({
                                                                                        beforeSend: function() {
                                                                                            try {
                                                                                                return r.find("span.state").text(plp.l10n("Загрузка..."))
                                                                                            } catch (e) {
                                                                                                error_handler(e, "libs_plp 10", arguments.callee)
                                                                                            }
                                                                                        },
                                                                                        uploadProgress: function(e, t, l, a) {
                                                                                            try {
                                                                                                return r.find("span.state").text(plp.l10n("Загрузка...") + " " + a + "%")
                                                                                            } catch (i) {
                                                                                                error_handler(i, "libs_plp 11", arguments.callee)
                                                                                            }
                                                                                        },
                                                                                        success: function(t) {
                                                                                            try {
                                                                                                return r.data("result", t),
                                                                                                    r.find("span.state").text(plp.l10n("Файл загружен")),
                                                                                                    e.remove(),
                                                                                                    l()
                                                                                            } catch (a) {
                                                                                                error_handler(a, "libs_plp 12", arguments.callee)
                                                                                            }
                                                                                        },
                                                                                        error: function(a) {
                                                                                            try {
                                                                                                return t(plp.l10n("Ошибка загрузки!"), 400 === a.status ? a.responseText : null),
                                                                                                    r.find("span.state").text(plp.l10n("Выберите файл...")),
                                                                                                    r.data("result", null),
                                                                                                    e.remove(),
                                                                                                    l()
                                                                                            } catch (i) {
                                                                                                error_handler(i, "libs_plp 13", arguments.callee)
                                                                                            }
                                                                                        },
                                                                                        dataType: "json"
                                                                                    })
                                                                            } catch (n) {
                                                                                error_handler(n, "libs_plp 9", arguments.callee)
                                                                            }
                                                                        })
                                                                    } catch (e) {
                                                                        error_handler(e, "libs_plp 8", arguments.callee)
                                                                    }
                                                                }
                                                            )()
                                                    } catch (n) {
                                                        error_handler(n, "libs_plp 6", arguments.callee)
                                                    }
                                                }),
                                                u.find("[data-placeholder]").each(function() {
                                                    try {
                                                        var e, r;
                                                        if (e = $(this),
                                                            e.attr("placeholder"))
                                                            return e.removeAttr("data-placeholder").data("placeholder", !1);
                                                        if (!e.val())
                                                            return;
                                                        return e.data("placeholder", !0),
                                                            r = e.val(),
                                                            e.on("focus", function(r) {
                                                                try {
                                                                    if (e.data("placeholder"))
                                                                        return e.val("").data("placeholder", !1)
                                                                } catch (t) {
                                                                    error_handler(t, "libs_plp 15", arguments.callee)
                                                                }
                                                            }),
                                                            e.on("blur", function(t) {
                                                                try {
                                                                    if ("" === e.val())
                                                                        return e.val(r).data("placeholder", !0)
                                                                } catch (l) {
                                                                    error_handler(l, "libs_plp 16", arguments.callee)
                                                                }
                                                            })
                                                    } catch (t) {
                                                        error_handler(t, "libs_plp 14", arguments.callee)
                                                    }
                                                }),
                                                p = u.find(".submit"),
                                                u.on("submit", function(e) {
                                                    try {
                                                        var a, i, d, f, v, g;
                                                        return e.preventDefault(),
                                                            $.now() - n < c ? void t(r.error, r.interval) : (d = [],
                                                                h.each(function(e) {
                                                                    try {
                                                                        var t;
                                                                        if ("checkbox-input" === y.fields[e].type ? y.fields[e].value = $(this).find("input").prop("checked") ? s : o : "radio-list" === y.fields[e].type ? y.fields[e].value = $(this).find("[type=radio]:checked").val() || "" : "select-menu" === y.fields[e].type ? y.fields[e].value = $(this).find("select").val() : "hidden" === y.fields[e].type ? (y.fields[e].name = y.fields[e].id,
                                                                            y.fields[e].value = $(this).find("input").val()) : "file" === y.fields[e].type ? y.fields[e].value = $(this).data("result") || "" : (t = $(this).find(".form-control").data("placeholder"),
                                                                            y.fields[e].value = t ? "" : $(this).find(".form-control").val()),
                                                                        y.fields[e].required && "" === y.fields[e].value && d.push(r.required.replace("%field%", y.fields[e].name)),
                                                                        "" === y.fields[e].value)
                                                                            return;
                                                                        if ("email" !== y.fields[e].type || /.+@.+\..+/.test(y.fields[e].value) || d.push(r.email.replace("%field%", y.fields[e].name)),
                                                                        "phone" === y.fields[e].type && !/.*\d.*\d.*\d.*\d.*/.test(y.fields[e].value))
                                                                            return d.push(r.phone.replace("%field%", y.fields[e].name))
                                                                    } catch (l) {
                                                                        error_handler(l, "libs_plp 18", arguments.callee)
                                                                    }
                                                                }),
                                                            "checkbox" === m.privacy && (a = u.closest(".body").find(".agreement-checkbox input").prop("checked"),
                                                                f = m.privacy_checkbox.replace(/[<>]/g, ""),
                                                            a === !1 && d.push(r.required.replace("%field%", f))),
                                                                d.length > 0 ? (u.trigger("submit-error"),
                                                                    void t(r.validate, d.join("\n"))) : (g = {
                                                                    name: "",
                                                                    phone: "",
                                                                    email: "",
                                                                    count: "",
                                                                    fields: {},
                                                                    item: {},
                                                                    send: y,
                                                                    items: []
                                                                },
                                                                    _.each(y.fields, function(e) {
                                                                        try {
                                                                            var r;
                                                                            if ("" === g[e.type] && (g[r = e.type] || (g[r] = e.value)),
                                                                                !g.fields[e.name])
                                                                                return g.fields[e.name] = e.value
                                                                        } catch (t) {
                                                                            error_handler(t, "libs_plp 19", arguments.callee)
                                                                        }
                                                                    }),
                                                                    _.each(y.item, function(e) {
                                                                        try {
                                                                            var r, t;
                                                                            return (r = g.item)[t = e.type] || (r[t] = _.escape(e.value))
                                                                        } catch (l) {
                                                                            error_handler(l, "libs_plp 20", arguments.callee)
                                                                        }
                                                                    }),
                                                                    _.each(y.items, function(e, r) {
                                                                        try {
                                                                            return g.items[r] = {},
                                                                                _.each(e, function(e) {
                                                                                    try {
                                                                                        var t, l, a, i;
                                                                                        "amount" === e.type || "photo" === e.type ? (t = g.items[r])[a = e.type] || (t[a] = e.value) : (l = g.items[r])[i = e.type] || (l[i] = _.escape(e.value))
                                                                                    } catch (n) {
                                                                                        error_handler(n, "libs_plp 22", arguments.callee)
                                                                                    }
                                                                                })
                                                                        } catch (t) {
                                                                            error_handler(t, "libs_plp 21", arguments.callee)
                                                                        }
                                                                    }),
                                                                m.payPrice && !g.items.length && g.items.push({
                                                                    amount: 1,
                                                                    price: m.payPrice,
                                                                    title: m.payTitle
                                                                }),
                                                                    p.prop("disabled", !0),
                                                                    v = function(e, a, i) {
                                                                        try {
                                                                            var n;
                                                                            return _.defaults(e, g),
                                                                                console.log("Form data", {
                                                                                    time: e.time,
                                                                                    name: e.name,
                                                                                    email: e.email,
                                                                                    phone: e.phone,
                                                                                    count: e.count,
                                                                                    fields: e.fields,
                                                                                    item: e.item,
                                                                                    items: e.items
                                                                                }),
                                                                                p.prop("disabled", !1),
                                                                                0 === e.result ? (t(r.error, e.errors),
                                                                                    u.trigger("submit-error")) : 1 === e.result ? (u.trigger("submit-success"),
                                                                                    $.cookie("form_submitted", "1", {
                                                                                        expires: 30
                                                                                    }),
                                                                                    "msg" === m.after ? l(_.template(m.msg, e), null) : "url" === m.after ? location.href = _.template(m.url, e) : "addhtml" === m.after ? $("body").append(_.template(m.addhtml, e)) : "pay" === m.after ? e.url ? location.href = e.url : e.form && $(e.form).hide().appendTo("body").submit() : "msg+url" === m.after ? l(_.template(m.msg, e), null, function() {
                                                                                        try {
                                                                                            return location.href = _.template(m.url, e)
                                                                                        } catch (r) {
                                                                                            error_handler(r, "libs_plp 24", arguments.callee)
                                                                                        }
                                                                                    }) : "msg+pay" === m.after ? l(_.template(m.msg, e), null, function() {
                                                                                        try {
                                                                                            if (e.url)
                                                                                                return location.href = e.url;
                                                                                            if (e.form)
                                                                                                return $(e.form).hide().appendTo("body").submit()
                                                                                        } catch (r) {
                                                                                            error_handler(r, "libs_plp 25", arguments.callee)
                                                                                        }
                                                                                    }) : "msg+addhtml" === m.after ? l(_.template(m.msg, e), null, function() {
                                                                                        try {
                                                                                            return $("body").append(_.template(m.addhtml, e))
                                                                                        } catch (r) {
                                                                                            error_handler(r, "libs_plp 26", arguments.callee)
                                                                                        }
                                                                                    }) : "js" === m.after && (n = "(function (data) { with (data) {" + m.js + "} })(<%= data %>);",
                                                                                        $.globalEval(_.template(n, {
                                                                                            data: JSON.stringify(e)
                                                                                        })))) : (t(r.error, null),
                                                                                    u.trigger("submit-error")),
                                                                                u.trigger("reset").find("[data-placeholder]").data("placeholder", !0),
                                                                            b.length && plp.cart.empty(),
                                                                                plp.modal.closeAll(),
                                                                                c = $.now()
                                                                        } catch (o) {
                                                                            error_handler(o, "libs_plp 23", arguments.callee)
                                                                        }
                                                                    }
                                                                    ,
                                                                    i = function(e, l, a) {
                                                                        try {
                                                                            return u.trigger("submit-error"),
                                                                                p.prop("disabled", !1),
                                                                                t(r.error, 400 === e.status ? e.responseText : null),
                                                                                c = $.now()
                                                                        } catch (i) {
                                                                            error_handler(i, "libs_plp 27", arguments.callee)
                                                                        }
                                                                    }
                                                                    ,
                                                                    $.ajax("/handler.php", {
                                                                        type: "POST",
                                                                        data: JSON.stringify(y),
                                                                        dataType: "json",
                                                                        contentType: "application/json",
                                                                        processData: !1,
                                                                        success: v,
                                                                        error: v
                                                                    })))
                                                    } catch (w) {
                                                        error_handler(w, "libs_plp 17", arguments.callee)
                                                    }
                                                })
                                        } catch (g) {
                                            error_handler(g, "libs_plp 5", arguments.callee)
                                        }
                                    })
                                } catch (p) {
                                    error_handler(p, "libs_plp 4", arguments.callee)
                                }
                            })
                    } catch (p) {
                        error_handler(p, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        plp.$ = window.$,
        $(function() {
            try {
                setTimeout(function() {
                    try {
                        creatium.api.init()
                    } catch (e) {
                        error_handler(e, "libs_plp 1", arguments.callee)
                    }
                }, 1)
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }),
        plp.closest = function(e, r) {
            try {
                var t = $(e)
                    , l = t.closest(r);
                if (l.length)
                    return l;
                var a = t.closest(".cr-portal");
                if (a.length)
                    return plp.closest(a.data("portal-parent"), r);
                var i = t.closest(".modal");
                return i.length ? plp.closest(i.data("$parent"), r) : $()
            } catch (n) {
                error_handler(n, "libs_plp 2", arguments.callee)
            }
        }
        ,
        function() {
            try {
                $(function() {
                    try {
                        var e, r, t, l;
                        if (r = function(e, r) {
                            try {
                                var t, l, a, i, n, c, o, s;
                                return s = $(window).height(),
                                    c = e.height(),
                                    n = parseInt(r.css("paddingTop"), 10),
                                    i = parseInt(r.css("paddingBottom"), 10),
                                    l = r.data("paddingTop"),
                                    a = r.data("paddingBottom"),
                                    t = s - c,
                                    o = t + n + i,
                                    o < l + a ? r.css({
                                        paddingTop: l,
                                        paddingBottom: a
                                    }) : r.css({
                                        paddingTop: Math.floor(o / 2),
                                        paddingBottom: Math.ceil(o / 2)
                                    })
                            } catch (d) {
                                error_handler(d, "libs_plp 2", arguments.callee)
                            }
                        }
                            ,
                            t = function(e) {
                                try {
                                    return e.each(function() {
                                        try {
                                            return r($(this), $(this).find(".wrapper2").first())
                                        } catch (e) {
                                            error_handler(e, "libs_plp 4", arguments.callee)
                                        }
                                    })
                                } catch (t) {
                                    error_handler(t, "libs_plp 3", arguments.callee)
                                }
                            }
                            ,
                            e = $(".section.fullheight"),
                        e.length > 0)
                            return e.each(function() {
                                try {
                                    var e;
                                    return e = $(this).find(".wrapper2").first(),
                                        e.data("paddingTop", parseInt(e.css("padding-top"), 10)),
                                        e.data("paddingBottom", parseInt(e.css("padding-bottom"), 10))
                                } catch (r) {
                                    error_handler(r, "libs_plp 5", arguments.callee)
                                }
                            }),
                                setTimeout(function() {
                                    try {
                                        return t(e)
                                    } catch (r) {
                                        error_handler(r, "libs_plp 6", arguments.callee)
                                    }
                                }, 100),
                                l = null,
                                $(window).on("resize", function() {
                                    try {
                                        return l && clearTimeout(l),
                                            l = setTimeout(function() {
                                                try {
                                                    return t(e),
                                                        l = null
                                                } catch (r) {
                                                    error_handler(r, "libs_plp 8", arguments.callee)
                                                }
                                            }, 100)
                                    } catch (r) {
                                        error_handler(r, "libs_plp 7", arguments.callee)
                                    }
                                })
                    } catch (a) {
                        error_handler(a, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        $(function() {
            try {
                var e = []
                    , r = ".modal-content, .sweet-overlay, .sweet-alert, #cboxOverlay, #colorbox"
                    , t = function(e, r) {
                    try {
                        var t = [];
                        $(e).find(r).each(function() {
                            try {
                                var e = $(this).parents().length;
                                t[e] ? t[e].push(this) : t[e] = [this]
                            } catch (r) {
                                error_handler(r, "libs_plp 2", arguments.callee)
                            }
                        });
                        for (var l = 0; l < t.length; l++)
                            if (t[l])
                                return $(t[l]);
                        return $()
                    } catch (a) {
                        error_handler(a, "libs_plp 1", arguments.callee)
                    }
                };
                plp.modal = {
                    init: function(e, r) {
                        try {
                            return e.on("click", function(e) {
                                try {
                                    plp.modal.open(r),
                                        e.preventDefault()
                                } catch (t) {
                                    error_handler(t, "libs_plp 4", arguments.callee)
                                }
                            })
                        } catch (t) {
                            error_handler(t, "libs_plp 3", arguments.callee)
                        }
                    },
                    open: function(r) {
                        try {
                            if (r = $(r),
                                r.triggerHandler("before-show"),
                            r.data("api_prevent") === !0)
                                return void r.data("api_prevent", !1);
                            var t = !!r.data("moved");
                            t === !1 && (r.modal({
                                backdrop: !1,
                                keyboard: !1,
                                show: !1
                            }),
                                r.data("moved", !0),
                                r.data("$parent", r.parent())),
                                r.appendTo("div.area"),
                                r.modal("show"),
                                r.before('<div class="modal-backdrop fade in"></div>'),
                                e.push(r),
                                plp.lazy.update(),
                                r.triggerHandler("show"),
                                $(creatium).triggerHandler("api-popup-show", [r])
                        } catch (l) {
                            error_handler(l, "libs_plp 5", arguments.callee)
                        }
                    },
                    isOpen: function(r) {
                        try {
                            return !!e.find(function(e) {
                                try {
                                    return r[0] === e[0]
                                } catch (t) {
                                    error_handler(t, "libs_plp 7", arguments.callee)
                                }
                            })
                        } catch (t) {
                            error_handler(t, "libs_plp 6", arguments.callee)
                        }
                    },
                    openbyid: function(e) {
                        try {
                            l.filter('[data-id="' + e + '"]:visible:first').click()
                        } catch (r) {
                            error_handler(r, "libs_plp 8", arguments.callee)
                        }
                    },
                    close: function() {
                        try {
                            var r = _.last(e).modal("hide");
                            if (r.triggerHandler("before-hide"),
                            r.data("api_prevent") === !0)
                                return void r.data("api_prevent", !1);
                            r.find(".macros-video").each(function() {
                                try {
                                    var e;
                                    return e = $(this).find(".wrap"),
                                        e.attr("src", e.attr("src").replace("autoplay=1", "autoplay=0"))
                                } catch (r) {
                                    error_handler(r, "libs_plp 10", arguments.callee)
                                }
                            }),
                                r.prev(".modal-backdrop").remove(),
                                e = _.without(e, r),
                                r.triggerHandler("hide"),
                                $(creatium).triggerHandler("api-popup-hide", [r])
                        } catch (t) {
                            error_handler(t, "libs_plp 9", arguments.callee)
                        }
                    },
                    closeAll: function() {
                        try {
                            if (!e.length)
                                return;
                            plp.modal.close(),
                                plp.modal.closeAll()
                        } catch (r) {
                            error_handler(r, "libs_plp 11", arguments.callee)
                        }
                    }
                };
                var l = $(".btn[data-modal], .btn-meta[data-modal], .btn-modal[data-modal]");
                l.each(function() {
                    try {
                        var e = $(this)
                            , r = e.attr("data-modal")
                            , l = e.closest(".node");
                        l.hasClass("widget-field") && (l = l.closest("[data-form]")),
                        l.length || (l = e.closest(".modal")),
                        ["cart", "agreement", "cookie"].indexOf(r) !== -1 && (l = $("div.area").first());
                        var a = t(l, '.modal[data-modal="' + r + '"]');
                        plp.modal.init(e, a)
                    } catch (i) {
                        error_handler(i, "libs_plp 12", arguments.callee)
                    }
                });
                var a = location.href.match(/#modal-([a-z0-9]+)/);
                return a && plp.modal.openbyid(a[1]),
                    $(document).on("click", 'a[href^="#modal-"]', function(e) {
                        try {
                            if (e.isDefaultPrevented())
                                return;
                            var r = $(this).attr("href").match(/#modal-([a-z0-9]+)/);
                            r && plp.modal.openbyid(r[1])
                        } catch (t) {
                            error_handler(t, "libs_plp 13", arguments.callee)
                        }
                    }),
                    $(document).on("click", function(t) {
                        try {
                            if (!e.length)
                                return;
                            if ($(t.target).closest(l).length)
                                return;
                            if ($(t.target).closest('a[href^="#modal-"]').length)
                                return;
                            var a = _.last(e);
                            if (t.target === a[0])
                                return plp.modal.close();
                            if ($(t.target).closest(".modal-header > .close").length)
                                return plp.modal.close();
                            var i = $(t.target).closest(".modal");
                            if (i.length && i[0] !== a[0])
                                return plp.modal.close();
                            if (!$(t.target).closest(r).length)
                                return plp.modal.close()
                        } catch (n) {
                            error_handler(n, "libs_plp 14", arguments.callee)
                        }
                    })
            } catch (i) {
                error_handler(i, "libs_plp 0", arguments.callee)
            }
        }),
        function() {
            try {
                $(function() {
                    try {
                        var e, r, t, l, a, i, n, c, o;
                        if ("scroll" !== window.plp.animations.section.type && "scroll" !== window.plp.animations.widget.type || (new WOW).init(),
                            $('[data-action="formscroll"]').each(function() {
                                try {
                                    var e, r, t, l, a;
                                    return a = $(this),
                                        r = a.closest(".section"),
                                        l = r.prevAll(".section"),
                                        t = r.nextAll(".section"),
                                        e = a.hasClass("btn") || a.hasClass("btn-meta") ? a : a.find(".btn, .btn-meta"),
                                        e.on("click", function() {
                                            try {
                                                var e, a, i;
                                                if (a = t.find(".form:visible, [data-form]:visible").first(),
                                                1 === a.length)
                                                    return $("html, body").animate({
                                                        scrollTop: a.offset().top - 100
                                                    }, {
                                                        duration: 1500,
                                                        easing: "easeInOutQuint"
                                                    });
                                                if (e = r.find(".form:visible, [data-form]:visible").first(),
                                                1 === e.length)
                                                    return $("html, body").animate({
                                                        scrollTop: e.offset().top - 100
                                                    }, {
                                                        duration: 1500,
                                                        easing: "easeInOutQuint"
                                                    });
                                                if (i = l.find(".form:visible, [data-form]:visible").last(),
                                                1 === i.length)
                                                    return $("html, body").animate({
                                                        scrollTop: i.offset().top - 100
                                                    }, {
                                                        duration: 1500,
                                                        easing: "easeInOutQuint"
                                                    })
                                            } catch (n) {
                                                error_handler(n, "libs_plp 3", arguments.callee)
                                            }
                                        })
                                } catch (i) {
                                    error_handler(i, "libs_plp 2", arguments.callee)
                                }
                            }),
                            r = $(".section.fixation-top").first(),
                            t = null,
                            a = !1,
                            plp.scrollTo = function(e, l) {
                                try {
                                    var i, n;
                                    if (null == l && (l = 0),
                                        n = e.offset().top,
                                    r.length && (n -= r.height()),
                                        $("html").hasClass("pp"))
                                        return i = e.closest(".pp-section").index(".pp-section"),
                                            i = e.closest(".pp-section").index(".pp-section"),
                                            $.fn.pagepiling.moveTo(i + 1);
                                    if (t)
                                        if (t.get(0) !== e.get(0))
                                            $("html,body").stop();
                                        else if (a)
                                            return;
                                    return $("html,body").animate({
                                        scrollTop: n + l
                                    }, {
                                        duration: 1e3,
                                        easing: "easeInOutCubic",
                                        always: function() {
                                            try {
                                                return a = !1
                                            } catch (e) {
                                                error_handler(e, "libs_plp 5", arguments.callee)
                                            }
                                        }
                                    }),
                                        a = !0,
                                        t = e
                                } catch (c) {
                                    error_handler(c, "libs_plp 4", arguments.callee)
                                }
                            }
                            ,
                            $(document).on("click", 'a[href^="#"]', function(e) {
                                try {
                                    var r;
                                    if (e.isDefaultPrevented())
                                        return;
                                    if (r = $($(this).attr("href")),
                                        r.length)
                                        return creatium.scrollTo(r),
                                            !1
                                } catch (t) {
                                    error_handler(t, "libs_plp 6", arguments.callee)
                                }
                            }),
                            l = location.href.match(/scrollblock=(\d+)/)) {
                            if (c = location.href.match(/scrolloffset=(-?\d+)/),
                                n = c.length ? 1 * c[1] : 0,
                                i = 1 * l[1],
                                e = $(".node.section").eq(i),
                                e.length)
                                return o = e.offset().top + n,
                                    $(document).scrollTop(o);
                            throw new Error("lib-scroll trying to scroll to unexisting " + i + " block")
                        }
                    } catch (s) {
                        error_handler(s, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        $(document).ready(function() {
            function e(e, r, t) {
                try {
                    var l = $.cookie(e);
                    l ? (l = JSON.parse(l),
                    l[r] || (l[r] = []),
                        l[r].push(t),
                        l = JSON.stringify(l)) : l = '{"' + r + '":["' + t + '"]}',
                        $.cookie(e, l)
                } catch (a) {
                    error_handler(a, "libs_plp 10", arguments.callee)
                }
            }
            function r(r) {
                try {
                    _.remove(m, function(t) {
                        try {
                            var l = t.modal == r;
                            if (l) {
                                r.parent(".macros-modal").remove();
                                var a = _.filter(t.section[0].classList, function(e) {
                                    try {
                                        return e.match(/node./gi)
                                    } catch (r) {
                                        error_handler(r, "libs_plp 13", arguments.callee)
                                    }
                                });
                                "page" == t.type && (a = "section-helper"),
                                    e(t.type + "_events", a, t.name)
                            }
                            return l
                        } catch (i) {
                            error_handler(i, "libs_plp 12", arguments.callee)
                        }
                    })
                } catch (t) {
                    error_handler(t, "libs_plp 11", arguments.callee)
                }
            }
            function t(e) {
                try {
                    if ("1" === $(".eventmodals").attr("disableEvent") && "1" === $.cookie("form_submitted"))
                        return;
                    h && ($.fn.pagepiling.setAllowScrolling(!1),
                        $("#pp-nav ul").hide()),
                        e.before('<div class="modal-backdrop fade in"></div>'),
                        e.modal({
                            show: !0,
                            backdrop: !1,
                            keyboard: !1
                        }),
                        e.find("button.close").eq(0).on("click", function() {
                            try {
                                e.modal("hide"),
                                    r(e),
                                h && ($.fn.pagepiling.setAllowScrolling(!0),
                                    $("#pp-nav ul").show())
                            } catch (t) {
                                error_handler(t, "libs_plp 15", arguments.callee)
                            }
                        })
                } catch (t) {
                    error_handler(t, "libs_plp 14", arguments.callee)
                }
            }
            function l(e, r) {
                try {
                    if (e.status)
                        return;
                    e.status = 1,
                        setTimeout(function() {
                            try {
                                t(e.modal)
                            } catch (r) {
                                error_handler(r, "libs_plp 17", arguments.callee)
                            }
                        }, r)
                } catch (l) {
                    error_handler(l, "libs_plp 16", arguments.callee)
                }
            }
            function a(e, r) {
                try {
                    u.count || (u.count = setTimeout(function() {
                        try {
                            t(e)
                        } catch (r) {
                            error_handler(r, "libs_plp 19", arguments.callee)
                        }
                    }, r))
                } catch (l) {
                    error_handler(l, "libs_plp 18", arguments.callee)
                }
            }
            function i() {
                try {
                    u.count && (u.count = clearTimeout(u.count))
                } catch (e) {
                    error_handler(e, "libs_plp 20", arguments.callee)
                }
            }
            function n() {
                try {
                    u.update.doubleback && (u.update.doubleback.status = 1),
                        u.update = {
                            doubleback: null
                        }
                } catch (e) {
                    error_handler(e, "libs_plp 21", arguments.callee)
                }
            }
            function c(e) {
                try {
                    u.section != e && (i(),
                        n()),
                        u.section = e
                } catch (r) {
                    error_handler(r, "libs_plp 22", arguments.callee)
                }
            }
            function o(e, r, l) {
                try {
                    var a, i, n = localStorage.user_visit;
                    n ? (n = JSON.parse(n),
                        a = {
                            first: n.first,
                            last: Date.now(),
                            count: n.count + 1
                        },
                        i = {
                            first: (Date.now() - n.first) / 1e3,
                            last: (Date.now() - n.last) / 1e3
                        },
                    i.last < e && a.count === r && t(l)) : a = {
                        first: Date.now(),
                        last: Date.now(),
                        count: 1
                    },
                        localStorage.user_visit = JSON.stringify(a)
                } catch (c) {
                    error_handler(c, "libs_plp 23", arguments.callee)
                }
            }
            function s(e, r) {
                try {
                    var l = parseInt(localStorage.user_lead);
                    Date.now() - l < 1e3 * e ? t(r) : u.formTracking || (_.each($(".section:not(.section-helper) .wrapper2 form"), function(e) {
                        try {
                            $(e).on("submit-done", function() {
                                try {
                                    localStorage.user_lead = Date.now()
                                } catch (e) {
                                    error_handler(e, "libs_plp 26", arguments.callee)
                                }
                            })
                        } catch (r) {
                            error_handler(r, "libs_plp 25", arguments.callee)
                        }
                    }),
                        u.formTracking = !0)
                } catch (a) {
                    error_handler(a, "libs_plp 24", arguments.callee)
                }
            }
            function d(e) {
                try {
                    if (e)
                        var i = _.filter(m, function(e) {
                            try {
                                return e.section[0] == u.section[0]
                            } catch (r) {
                                error_handler(r, "libs_plp 29", arguments.callee)
                            }
                        });
                    else
                        var n = {
                            top: $(document).scrollTop(),
                            height: document.documentElement.clientHeight,
                            bottom: $(document).scrollTop() + document.documentElement.clientHeight
                        }
                            , i = _.filter(m, function(e) {
                            try {
                                var r, t = e.height() <= n.height;
                                return r = t ? e.bottom() <= n.bottom && e.top() >= n.top : e.top() <= n.top && e.bottom() >= n.bottom
                            } catch (l) {
                                error_handler(l, "libs_plp 28", arguments.callee)
                            }
                        });
                    var d = {
                        inview: _.filter(i, {
                            name: "inview"
                        })[0],
                        longview: _.filter(i, {
                            name: "longview"
                        })[0],
                        doubleback: _.filter(i, {
                            name: "doubleback"
                        })[0],
                        doublecancel: _.filter(i, {
                            name: "doublecancel"
                        })[0],
                        leave: _.filter(m, {
                            name: "leave"
                        })[0],
                        pagelongview: _.filter(m, {
                            name: "pagelongview"
                        })[0],
                        pagelongview2min: _.filter(m, {
                            name: "pagelongview2min"
                        })[0],
                        pagelongview4min: _.filter(m, {
                            name: "pagelongview4min"
                        })[0],
                        scrollend: _.filter(m, {
                            name: "scrollend"
                        })[0],
                        doubleerror: _.filter(m, {
                            name: "doubleerror"
                        })[0],
                        hourlyvisit: _.filter(m, {
                            name: "hourlyvisit"
                        })[0],
                        weeklyvisit: _.filter(m, {
                            name: "weeklyvisit"
                        })[0],
                        leadback_hour: _.filter(m, {
                            name: "leadback_hour"
                        })[0],
                        leadback_day: _.filter(m, {
                            name: "leadback_day"
                        })[0],
                        leadback_week: _.filter(m, {
                            name: "leadback_week"
                        })[0],
                        leadback_month: _.filter(m, {
                            name: "leadback_month"
                        })[0]
                    };
                    if (!$(".modal:visible").length) {
                        if (!e) {
                            var p = i.length ? i[0].section : null;
                            c(p)
                        }
                        if (d.inview && t(d.inview.modal),
                        d.longview && a(d.longview.modal, 6e4),
                        d.doubleback && (d.doubleback.status ? t(d.doubleback.modal) : u.update.doubleback || (u.update.doubleback = d.doubleback)),
                        d.doublecancel && !d.doublecancel.status) {
                            var h = $(d.doublecancel.section).find(".wrapper2 .modal")
                                , f = _.remove(h, function(e) {
                                try {
                                    var r = $(e).find("form");
                                    return r.length
                                } catch (t) {
                                    error_handler(t, "libs_plp 30", arguments.callee)
                                }
                            });
                            f.length && (_.each(f, function(e) {
                                try {
                                    var l = 0;
                                    $(e).on("hide.bs.modal", function() {
                                        try {
                                            1 === l ? (_.each(f, function(e) {
                                                try {
                                                    $(e).off("hide.bs.modal").off("submit-done")
                                                } catch (r) {
                                                    error_handler(r, "libs_plp 33", arguments.callee)
                                                }
                                            }),
                                                t(d.doublecancel.modal)) : l++
                                        } catch (e) {
                                            error_handler(e, "libs_plp 32", arguments.callee)
                                        }
                                    }).on("submit-done", function() {
                                        try {
                                            d.doublecancel.status = d.doublecancel.status - 1,
                                            d.doublecancel.status || r(d.doublecancel.modal),
                                                $(e).off("hide.bs.modal").off("submit-done")
                                        } catch (t) {
                                            error_handler(t, "libs_plp 34", arguments.callee)
                                        }
                                    })
                                } catch (a) {
                                    error_handler(a, "libs_plp 31", arguments.callee)
                                }
                            }),
                                d.doublecancel.status = f.length)
                        }
                        if (d.leave && !d.leave.status && (d.leave.status = 1,
                            $(document).on("mouseleave", function(e) {
                                try {
                                    if (3 != e.which) {
                                        var r = document.documentElement.clientWidth - e.pageX > 0;
                                        r && ($(document).off("mouseleave"),
                                            t(d.leave.modal))
                                    }
                                } catch (l) {
                                    error_handler(l, "libs_plp 35", arguments.callee)
                                }
                            })),
                        d.pagelongview && l(d.pagelongview, 6e4),
                        d.pagelongview2min && l(d.pagelongview2min, 12e4),
                        d.pagelongview4min && l(d.pagelongview4min, 24e4),
                            d.scrollend) {
                            var v = $(".section-helper").index(".section") - 1
                                , b = !1;
                            if (e)
                                b = v === u.section.index(".section");
                            else {
                                var y = $(".section").eq(v).offset().top
                                    , g = $(".section").eq(v).height()
                                    , w = $(document).scrollTop() + document.documentElement.clientHeight;
                                b = y + g == w
                            }
                            b && t(d.scrollend.modal)
                        }
                        if (d.doubleerror) {
                            var x = $(".section:not(.section-helper) .wrapper2 form");
                            _.each(x, function(e) {
                                try {
                                    var r = 0;
                                    $(e).on("submit-error", function() {
                                        try {
                                            1 === r ? (_.each(x, function(e) {
                                                try {
                                                    $(e).off("submit-error")
                                                } catch (r) {
                                                    error_handler(r, "libs_plp 38", arguments.callee)
                                                }
                                            }),
                                                $(".modal:visible").find(".close").click(),
                                                t(d.doubleerror.modal)) : r++
                                        } catch (e) {
                                            error_handler(e, "libs_plp 37", arguments.callee)
                                        }
                                    })
                                } catch (l) {
                                    error_handler(l, "libs_plp 36", arguments.callee)
                                }
                            })
                        }
                        d.hourlyvisit && o(1800, 2, d.hourlyvisit.modal),
                        d.weeklyvisit && o(604800, 3, d.weeklyvisit.modal),
                        d.leadback_hour && s(3600, d.leadback_hour.modal),
                        d.leadback_day && s(25200, d.leadback_day.modal),
                        d.leadback_week && s(604800, d.leadback_week.modal),
                        d.leadback_month && s(18748800, d.leadback_month.modal)
                    }
                } catch (k) {
                    error_handler(k, "libs_plp 27", arguments.callee)
                }
            }
            function p() {
                try {
                    for (var e = !1, r = 0; r < f.elements.length; r++) {
                        var t = f.elements[r]
                            , l = t.$section.offset().top
                            , a = t.$section.height()
                            , i = $(document).scrollTop() + f.fixationHeight + window.innerHeight / 4;
                        i >= l && i <= l + a + window.innerHeight / 4 && (t !== f.$previousReaction && (f.$previousReaction && f.$previousReaction.$buttons.find('button[need_hover="true"]').removeClass("hover hover-on-scroll"),
                            t.$buttons.find('button[need_hover="true"]').addClass("hover hover-on-scroll"),
                            f.$previousReaction = t),
                            e = !0)
                    }
                    !e && f.$previousReaction && (f.$previousReaction.$buttons.find('button[need_hover="true"]').removeClass("hover hover-on-scroll"),
                        f.$previousReaction = null)
                } catch (n) {
                    error_handler(n, "libs_plp 39", arguments.callee)
                }
            }
            try {
                window.plp.events = [];
                var h = "slider" == window.plp.animations.section.type
                    , u = {
                    count: null,
                    section: null,
                    update: {
                        doubleback: null
                    },
                    formTracking: !1
                }
                    , f = {
                    elements: [],
                    $previousReaction: null,
                    fixationHeight: $(".section.fixation-top").height() || 0
                };
                _.each($(".section"), function(e, r) {
                    try {
                        var t = $(e);
                        if (t.hasClass("section-helper"))
                            var l = t.find(".eventmodals .modal")
                                , a = "page";
                        else
                            var l = t.find("> .macros-modal > .modal")
                                , a = "section";
                        var i = $.cookie(a + "_events")
                            , n = [];
                        if (i && (i = JSON.parse(i),
                            _.map(_.keys(i), function(e) {
                                try {
                                    t.hasClass(e) && (n = i[e])
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            })),
                            _.each(l, function(e, r) {
                                try {
                                    var i = {
                                        name: $(e).attr("data-modal"),
                                        section: t,
                                        modal: $(e),
                                        type: a
                                    };
                                    h || _.merge(i, {
                                        top: function() {
                                            try {
                                                return t.offset().top
                                            } catch (e) {
                                                error_handler(e, "libs_plp 4", arguments.callee)
                                            }
                                        },
                                        height: function() {
                                            try {
                                                return t.outerHeight()
                                            } catch (e) {
                                                error_handler(e, "libs_plp 5", arguments.callee)
                                            }
                                        },
                                        bottom: function() {
                                            try {
                                                return t.outerHeight() + t.offset().top
                                            } catch (e) {
                                                error_handler(e, "libs_plp 6", arguments.callee)
                                            }
                                        }
                                    });
                                    var c = !1;
                                    if ("section" == a && "inview" == i.name) {
                                        var o = !h && i.bottom() < document.documentElement.clientHeight;
                                        c = i.section.is($(".section").eq(0)) || o
                                    }
                                    if ("page" == a) {
                                        var s = _.filter(window.plp.events, {
                                            type: "section"
                                        })
                                            , d = _.map(l, function(e) {
                                            try {
                                                return $(e).attr("data-modal")
                                            } catch (r) {
                                                error_handler(r, "libs_plp 7", arguments.callee)
                                            }
                                        })
                                            , p = {
                                            first: $(".section").eq(0),
                                            last: $(".section").eq($(".section-helper").index(".section") - 1)
                                        };
                                        if ("hourlyvisit" == i.name) {
                                            var u = (_.indexOf(d, "weeklyvisit") != -1,
                                                "leadback_hour")
                                                , f = _.indexOf(d, u) != -1;
                                            c = m || f
                                        }
                                        if ("weeklyvisit" == i.name) {
                                            var u = "leadback_hour"
                                                , f = _.indexOf(d, u) != -1;
                                            c = f
                                        }
                                        if ("leadback_hour" == i.name) {
                                            var m = _.indexOf(d, "leadback_day") != -1;
                                            c = m
                                        }
                                        if ("leadback_day" == i.name) {
                                            var m = _.indexOf(d, "leadback_week") != -1;
                                            c = m
                                        }
                                        if ("leadback_week" == i.name) {
                                            var m = _.indexOf(d, "leadback_month") != -1;
                                            c = m
                                        }
                                        "scrollend" == i.name && (c = _.filter(s, function(e) {
                                            try {
                                                return "inview" == e.name && e.section.is(p.last)
                                            } catch (r) {
                                                error_handler(r, "libs_plp 8", arguments.callee)
                                            }
                                        }).length),
                                        "pagelongview" != i.name && "pagelongview2min" != i.name && "pagelongview4min" != i.name || (c = _.filter(s, function(e) {
                                            try {
                                                return "longview" == e.name && e.section.is(p.first)
                                            } catch (r) {
                                                error_handler(r, "libs_plp 9", arguments.callee)
                                            }
                                        }).length)
                                    }
                                    _.indexOf(n, i.name) != -1 || c ? $(e).parent(".macros-modal").remove() : window.plp.events.push(i)
                                } catch (v) {
                                    error_handler(v, "libs_plp 3", arguments.callee)
                                }
                            }),
                        void 0 !== t.attr("id")) {
                            var c = $('a[href="#' + t.attr("id") + '"]');
                            f.elements.push({
                                $section: t,
                                $buttons: c
                            })
                        }
                    } catch (o) {
                        error_handler(o, "libs_plp 1", arguments.callee)
                    }
                });
                var m = window.plp.events;
                h ? (c($(".pp-section.active")),
                    $("div.area").on("leave", function(e, r) {
                        try {
                            c($(".section").eq(r - 1))
                        } catch (t) {
                            error_handler(t, "libs_plp 40", arguments.callee)
                        }
                    }),
                    $("div.area").on("afterLoad", function(e, r) {
                        try {
                            d(h)
                        } catch (t) {
                            error_handler(t, "libs_plp 41", arguments.callee)
                        }
                    })) : $(window).on("scroll", function() {
                    try {
                        d(h),
                            p()
                    } catch (e) {
                        error_handler(e, "libs_plp 42", arguments.callee)
                    }
                }),
                    $(window).on("resize", function() {
                        try {
                            d(h)
                        } catch (e) {
                            error_handler(e, "libs_plp 43", arguments.callee)
                        }
                    }),
                    d(h),
                    setTimeout(p, 500)
            } catch (v) {
                error_handler(v, "libs_plp 0", arguments.callee)
            }
        }),
        function() {
            try {
                $(function() {
                    try {
                        return $(".node[data-bgsnow]").each(function() {
                            try {
                                var e, r, t;
                                return e = $(this),
                                    r = e.data("bgsnow"),
                                    e.removeAttr("data-bgsnow"),
                                    t = new Snowfall({
                                        root: e.find("> .wrapper1 > .wrapper2").get(0),
                                        type: "text",
                                        content: ["*", "&#10052", "&#10053", "&#10054", "."],
                                        minSize: 10,
                                        maxSize: 30
                                    }),
                                    e.data("bgsnow", t)
                            } catch (l) {
                                error_handler(l, "libs_plp 2", arguments.callee)
                            }
                        })
                    } catch (e) {
                        error_handler(e, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        $(function() {
            try {
                plp.cart = {},
                    plp.cart.getPrice = function(e) {
                        try {
                            var r = e.match(/\d/g);
                            if (!r)
                                return 0;
                            var t = e.indexOf(r[0])
                                , l = e.lastIndexOf(r[r.length - 1])
                                , a = (e[t],
                                e[l],
                                e.substring(t, l + 1));
                            a = a.replace(/[^\d\.\,]+/g, "");
                            var i = a.indexOf(".") >= 0
                                , n = a.indexOf(",") >= 0;
                            if (i || n) {
                                var r = a.match(/(.+)[\,\.](\d\d)$/);
                                if (r)
                                    var c = 1 * r[1].replace(/[\,\.]/g, "")
                                        , o = 1 * ("0." + r[2])
                                        , s = c + o;
                                else
                                    var s = 1 * a.replace(/[\,\.]/g, "")
                            } else
                                var s = 1 * a;
                            return s
                        } catch (d) {
                            error_handler(d, "libs_plp 1", arguments.callee)
                        }
                    }
                    ,
                    plp.cart.getCurrency = function(e) {
                        try {
                            var r = e.match(/\d/g);
                            if (!r)
                                return "%s%";
                            e = e.replace(/\&nbsp\;/g, " ");
                            var t = e.match(/[\:\-]/);
                            t && (e = e.replace(/.*[\:\-]\s*(.*)/, "$1"));
                            var l = e.indexOf(r[0])
                                , a = e.lastIndexOf(r[r.length - 1])
                                , i = (e[l],
                                e[a],
                                e.substring(l, a + 1));
                            return e.replace(i, "%s%")
                        } catch (n) {
                            error_handler(n, "libs_plp 2", arguments.callee)
                        }
                    }
                ;
                var e = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                    , r = $('[data-modal="cart"]')
                    , t = r.find(".cont").first()
                    , l = t.next();
                t.find('[data-role="itemphoto"]').attr("data-lazy-bgimage", e),
                    plp.lazy.add(r, function() {
                        try {
                            plp.lazy.force(t),
                                plp.lazy.force(l)
                        } catch (e) {
                            error_handler(e, "libs_plp 3", arguments.callee)
                        }
                    });
                var a = t.find(".node.widget-cart-list").first()
                    , i = a.children(".wrapper1").children(".wrapper2")
                    , n = i.children(".cont");
                plp.lazy.force(n),
                    a.data("template", n.parent().html()),
                    n.remove();
                var c = $();
                plp.cart.add = function(r) {
                    try {
                        var t = _.filter(r, {
                            type: "title"
                        })[0]
                            , l = _.filter(r, {
                            type: "price"
                        })[0]
                            , n = _.filter(r, {
                            type: "amount"
                        })[0]
                            , o = _.filter(r, {
                            type: "photo"
                        })[0]
                            , s = !1;
                        if (_.each(plp.cart.list, function(e, r) {
                            try {
                                var a = _.filter(e, {
                                    type: "title"
                                })[0]
                                    , c = _.filter(e, {
                                    type: "price"
                                })[0]
                                    , o = _.filter(e, {
                                    type: "amount"
                                })[0];
                                t.value === a.value && l.value === c.value && (o.value += 1 * n.value,
                                    i.children().eq(r).trigger("setamount", [o.value]),
                                    s = !0)
                            } catch (d) {
                                error_handler(d, "libs_plp 5", arguments.callee)
                            }
                        }),
                            s)
                            return store.set("cart", plp.cart.list),
                            plp.cart._api_ready && $(creatium).triggerHandler("api-cart-item-add", [r]),
                            plp.cart._api_ready && $(creatium).triggerHandler("cart-change"),
                                void plp.cart.update();
                        plp.cart.list.push(r),
                            store.set("cart", plp.cart.list),
                        plp.cart._api_ready && $(creatium).triggerHandler("cart-change"),
                            plp.cart.update();
                        var d = $(a.data("template"));
                        i.append(d),
                            d.find('[data-role="setamount"]').val(n.value),
                            d.find('[data-role="itemprice"]').html(l.value),
                            d.find('[data-role="itemname"]').html(t.value),
                            d.find('[data-role="itemphoto"]').css("backgroundImage", 'url("' + (o.value || e) + '")').removeAttr("data-lazy-bgimage").removeAttr("data-lazy-bgimage_size"),
                            c = c.add(d),
                            d.on("setamount", function(e, r) {
                                try {
                                    n.value = r,
                                        store.set("cart", plp.cart.list),
                                        d.find('[data-role="setamount"]').val(r),
                                        n.value ? (plp.cart._api_ready && $(creatium).triggerHandler("cart-change"),
                                            plp.cart.update()) : d.trigger("removefromcart")
                                } catch (t) {
                                    error_handler(t, "libs_plp 6", arguments.callee)
                                }
                            }),
                            d.on("removefromcart", function(e) {
                                try {
                                    plp.cart.list.splice(plp.cart.list.indexOf(r), 1),
                                        store.set("cart", plp.cart.list),
                                    plp.cart._api_ready && $(creatium).triggerHandler("api-cart-item-remove", [r]),
                                    plp.cart._api_ready && $(creatium).triggerHandler("cart-change"),
                                        d.slideUp(250, function() {
                                            try {
                                                d.remove(),
                                                    c = c.not(d),
                                                    plp.cart.update()
                                            } catch (e) {
                                                error_handler(e, "libs_plp 8", arguments.callee)
                                            }
                                        })
                                } catch (t) {
                                    error_handler(t, "libs_plp 7", arguments.callee)
                                }
                            }),
                            d.find('[data-role="removefromcart"]').on("click", function() {
                                try {
                                    d.trigger("removefromcart")
                                } catch (e) {
                                    error_handler(e, "libs_plp 9", arguments.callee)
                                }
                            }),
                            d.find('[data-role="setamount"]').on("change", function() {
                                try {
                                    var e = 1 * $(this).val();
                                    d.trigger("setamount", [e])
                                } catch (r) {
                                    error_handler(r, "libs_plp 10", arguments.callee)
                                }
                            }),
                            d.find('[data-role="increaseamount"]').on("click", function() {
                                try {
                                    var e = n.value + 1;
                                    d.trigger("setamount", [e])
                                } catch (r) {
                                    error_handler(r, "libs_plp 11", arguments.callee)
                                }
                            }),
                            d.find('[data-role="decreaseamount"]').on("click", function() {
                                try {
                                    var e = n.value - 1;
                                    d.trigger("setamount", [e])
                                } catch (r) {
                                    error_handler(r, "libs_plp 12", arguments.callee)
                                }
                            })
                    } catch (p) {
                        error_handler(p, "libs_plp 4", arguments.callee)
                    }
                }
                    ,
                    plp.cart.update = function() {
                        try {
                            var e, r = 0, a = 0;
                            if (_.each(plp.cart.list, function(t) {
                                try {
                                    var l = 1 * _.filter(t, {
                                        type: "amount"
                                    })[0].value
                                        , i = _.filter(t, {
                                        type: "price"
                                    })[0].value;
                                    r += l,
                                        a += plp.cart.getPrice(i) * l,
                                        e = e || plp.cart.getCurrency(i)
                                } catch (n) {
                                    error_handler(n, "libs_plp 14", arguments.callee)
                                }
                            }),
                                $('.btn[data-modal="cart"] *, .btn-meta[data-modal="cart"] *').each(function() {
                                    try {
                                        $(this).contents().each(function() {
                                            try {
                                                3 === this.nodeType && this.data.match(/\d/) && (this.data = this.data.replace(/\d+/, r))
                                            } catch (e) {
                                                error_handler(e, "libs_plp 16", arguments.callee)
                                            }
                                        })
                                    } catch (e) {
                                        error_handler(e, "libs_plp 15", arguments.callee)
                                    }
                                }),
                                !plp.cart.list.length)
                                return $('[data-role="carttotal"] span').html("-"),
                                    l.show(),
                                    void t.hide();
                            t.show(),
                                l.hide(),
                                $('[data-role="carttotal"] span').html(e.replace("%s%", a))
                        } catch (i) {
                            error_handler(i, "libs_plp 13", arguments.callee)
                        }
                    }
                    ,
                    plp.cart.empty = function() {
                        try {
                            c.trigger("removefromcart")
                        } catch (e) {
                            error_handler(e, "libs_plp 17", arguments.callee)
                        }
                    }
                    ,
                    plp.cart.list = [],
                    (store.get("cart") || []).forEach(function(e) {
                        try {
                            plp.cart.add(e)
                        } catch (r) {
                            error_handler(r, "libs_plp 18", arguments.callee)
                        }
                    }),
                    plp.cart._api_ready = !0,
                    plp.cart.update(),
                    $(document.body).on("click", '[data-action="addtocart"]', function(e) {
                        try {
                            var r = $(e.currentTarget).closest("[data-item]");
                            if (!r.length)
                                return void swal(plp.l10n("Товар не найден"), plp.l10n("Кнопка должна находиться в карточке товара."), "error");
                            var t = _.cloneDeep(r.data("item"))
                                , l = r.find('[data-role="setamount"]');
                            if (l.length)
                                var a = {
                                    name: plp.l10n("Количество"),
                                    type: "amount",
                                    value: 1 * l.val() || 1
                                };
                            else
                                var a = {
                                    name: plp.l10n("Количество"),
                                    type: "amount",
                                    value: 1
                                };
                            if (t.push(a),
                                !r.find('[data-role="image"]').length) {
                                var i = _.filter(t, {
                                    type: "photo"
                                })[0];
                                i.value = !1
                            }
                            plp.cart.add(t),
                                swal({
                                    title: plp.l10n("Добавлено в корзину!"),
                                    type: "success",
                                    showCancelButton: !0,
                                    cancelButtonText: plp.l10n("ОК"),
                                    confirmButtonText: plp.l10n("Открыть корзину")
                                }, function() {
                                    try {
                                        $('.btn[data-modal="cart"], .btn-meta[data-modal="cart"]').first().click()
                                    } catch (e) {
                                        error_handler(e, "libs_plp 20", arguments.callee)
                                    }
                                })
                        } catch (n) {
                            error_handler(n, "libs_plp 19", arguments.callee)
                        }
                    })
            } catch (o) {
                error_handler(o, "libs_plp 0", arguments.callee)
            }
        }),
        function() {
            try {
                var e;
                "slider" === window.plp.animations.section.type && (e = function() {
                        try {
                            var r;
                            if (!window.plp.screen)
                                return setTimeout(e, 10);
                            if ("xs" !== window.plp.screen)
                                return $("html").addClass("pp"),
                                    $("div.area").pagepiling({
                                        menu: null,
                                        direction: "vertical",
                                        verticalCentered: !1,
                                        sectionsColor: [],
                                        anchors: [],
                                        scrollingSpeed: 700,
                                        easing: "swing",
                                        loopBottom: !1,
                                        loopTop: !1,
                                        css3: !0,
                                        navigation: {
                                            bulletsColor: "#fff",
                                            position: "right"
                                        },
                                        normalScrollElements: null,
                                        normalScrollElementTouchThreshold: 5,
                                        touchSensitivity: 5,
                                        keyboardScrolling: !0,
                                        sectionSelector: ".section:not(.section-helper)",
                                        animateAnchor: !1,
                                        onLeave: function(e, r, t) {
                                            try {
                                                var l;
                                                if ($("div.area").trigger("leave", [r]),
                                                    $(".pp-section").eq(e - 1).find(".wow").addClass("wow-finished"),
                                                    $(".pp-section").eq(r - 1).find(".wow:not(.wow-finished)").removeAttr("style").css({
                                                        visibility: "hidden"
                                                    }),
                                                    l = function(e, r) {
                                                        try {
                                                            return setTimeout(r, e)
                                                        } catch (t) {
                                                            error_handler(t, "libs_plp 3", arguments.callee)
                                                        }
                                                    }
                                                    ,
                                                    $(".wow:not(.wow-finished)").length)
                                                    return l(700, function() {
                                                        try {
                                                            return $(".pp-section").eq(r - 1).find(".wow").css({
                                                                visibility: "visible"
                                                            }),
                                                                (new WOW).init()
                                                        } catch (e) {
                                                            error_handler(e, "libs_plp 4", arguments.callee)
                                                        }
                                                    })
                                            } catch (a) {
                                                error_handler(a, "libs_plp 2", arguments.callee)
                                            }
                                        },
                                        afterLoad: function(e, r) {
                                            try {
                                                return $("div.area").trigger("afterLoad", [r])
                                            } catch (t) {
                                                error_handler(t, "libs_plp 5", arguments.callee)
                                            }
                                        }
                                    }),
                                    r = function() {
                                        try {
                                            var e;
                                            return e = $("div.area").height(),
                                                $(".pp-section>.wrapper1, .pp-section>.wrapper1>.wrapper2").css({
                                                    height: e
                                                })
                                        } catch (r) {
                                            error_handler(r, "libs_plp 6", arguments.callee)
                                        }
                                    }
                                    ,
                                    r(),
                                    $(window).on("resize", r)
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    }
                )()
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        plp.isRetina = function() {
            try {
                if (window.devicePixelRatio > 1)
                    return !0;
                var e = "(-webkit-min-device-pixel-ratio: 1.5), (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (min-resolution: 1.5dppx)";
                return !(!window.matchMedia || !window.matchMedia(e).matches)
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }
        ,
        function() {
            try {
                $(function() {
                    try {
                        return $(".node[data-bgvideo]").each(function() {
                            try {
                                var e, r;
                                return e = $(this),
                                    r = e.data("bgvideo"),
                                    plp.lazy.add(e.removeAttr("data-bgvideo"), function(t) {
                                        try {
                                            var l;
                                            if ("youtube" === r.bgVideo_Source)
                                                return l = $("<div></div>").prependTo(e.children(".wrapper1")),
                                                    l.data("property", {
                                                        videoURL: r.bgVideo_Youtube,
                                                        containment: l,
                                                        mute: !0,
                                                        showControls: !1
                                                    }).YTPlayer();
                                            if ("direct" === r.bgVideo_Source || "library" === r.bgVideo_Source)
                                                return l = e.children(".wrapper1"),
                                                    l.vide({
                                                        mp4: r.bgVideo_Mp4,
                                                        webm: r.bgVideo_Webm,
                                                        ogv: r.bgVideo_Ogv
                                                    }, {
                                                        mute: !0,
                                                        autoplay: !0,
                                                        loop: !0,
                                                        posterType: "none"
                                                    })
                                        } catch (a) {
                                            error_handler(a, "libs_plp 3", arguments.callee)
                                        }
                                    })
                            } catch (t) {
                                error_handler(t, "libs_plp 2", arguments.callee)
                            }
                        })
                    } catch (e) {
                        error_handler(e, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }
            .call(this),
        $.lazyLoadXT.autoInit = !1,
        $.lazyLoadXT.edgeY = 1e3,
        $.lazyLoadXT.updateEvent += " lazyupdate",
        $.lazyLoadXT.oninit = {},
        $.lazyLoadXT.onshow = {},
        $.lazyLoadXT.onload = {},
        $.lazyLoadXT.onerror = {},
        plp.lazy = {
            add: function(e, r, t) {
                try {
                    return e.addClass("lazy").lazyLoadXT({
                        edgeY: void 0 !== t ? t : plp.lazy.distance()
                    }).one("lazyshow", function(e) {
                        try {
                            var t = $(this);
                            t.removeClass("lazy"),
                                r(t),
                                e.stopPropagation()
                        } catch (l) {
                            error_handler(l, "libs_plp 1", arguments.callee)
                        }
                    }),
                        plp.lazy.update(),
                        e
                } catch (l) {
                    error_handler(l, "libs_plp 0", arguments.callee)
                }
            },
            trigger: function(e) {
                try {
                    return e.trigger("lazyshow")
                } catch (r) {
                    error_handler(r, "libs_plp 2", arguments.callee)
                }
            },
            force: function(e) {
                try {
                    e = e || $("div.area");
                    var r = e.find(".lazy").filter(function() {
                        try {
                            return 0 === $(this).parentsUntil(e).filter(".modal").length
                        } catch (r) {
                            error_handler(r, "libs_plp 4", arguments.callee)
                        }
                    });
                    return plp.lazy.trigger(r),
                        e
                } catch (t) {
                    error_handler(t, "libs_plp 3", arguments.callee)
                }
            },
            update: function() {
                try {
                    $(document).trigger("lazyupdate")
                } catch (e) {
                    error_handler(e, "libs_plp 5", arguments.callee)
                }
            },
            distance: function(e) {
                try {
                    return e && ($.lazyLoadXT.edgeY = 1 * e,
                        plp.lazy.update()),
                        $.lazyLoadXT.edgeY
                } catch (r) {
                    error_handler(r, "libs_plp 6", arguments.callee)
                }
            }
        },
        $(function() {
            function e(e) {
                try {
                    var r = e.w << 16 | e.h << 2 | e.c
                        , t = e.b << 16 | e.q << 6
                        , l = r.toString(29)
                        , a = t.toString(29)
                        , i = +r.toString().substring(0, 1) + +t.toString().substring(0, 1);
                    return i.toString(29) + l + a + (l.length.toString(29) + a.length.toString(29))
                } catch (n) {
                    error_handler(n, "libs_plp 8", arguments.callee)
                }
            }
            function r(e) {
                try {
                    return /\/\/u\d*\.platformalp\.ru/.test(e) || /\/\/u\d*\.filesonload\.ru/.test(e) || /\/\/u\d*\.plpstatic\.ru/.test(e)
                } catch (r) {
                    error_handler(r, "libs_plp 9", arguments.callee)
                }
            }
            function t(r, t) {
                try {
                    plp.isRetina() && t.retina && (t.width2 *= 2,
                        t.height2 *= 2);
                    var l = Math.min(t.width1, 2e3)
                        , a = Math.min(t.height1, 2e3);
                    t.width2 > l && (t.height2 = l / t.width2 * t.height2,
                        t.width2 = l),
                    t.height2 > a && (t.width2 = a / t.height2 * t.width2,
                        t.height2 = a);
                    var i = e({
                        h: t.height2 || 1,
                        w: t.width2 || 1
                    });
                    return r.replace(/(.+?.\w+)\/(.+)/, "$1/s/" + i + "/$2")
                } catch (n) {
                    error_handler(n, "libs_plp 10", arguments.callee)
                }
            }
            try {
                plp.lazy.add($("[data-lazy-iframe]"), function(e) {
                    try {
                        e.attr("src", e.attr("data-lazy-iframe")),
                            e.removeAttr("data-lazy-iframe"),
                            e.addClass("lazy-loading"),
                            e.on("load", function() {
                                try {
                                    e.removeClass("lazy-loading"),
                                        e.trigger("lazyload")
                                } catch (r) {
                                    error_handler(r, "libs_plp 12", arguments.callee)
                                }
                            }).on("error", function() {
                                try {
                                    e.removeClass("lazy-loading"),
                                        e.trigger("lazyerror")
                                } catch (r) {
                                    error_handler(r, "libs_plp 13", arguments.callee)
                                }
                            })
                    } catch (r) {
                        error_handler(r, "libs_plp 11", arguments.callee)
                    }
                }),
                    plp.lazy.add($("[data-lazy-image]"), function(e) {
                        try {
                            var l = e.attr("data-lazy-image");
                            if (r(l) && "true" !== e.attr("data-lazy-image_noscale")) {
                                var a = e.attr("data-lazy-image_size").split(",")
                                    , i = {
                                    retina: "true" !== e.attr("data-lazy-image_nohd"),
                                    width1: 1 * a[0],
                                    width2: 1 * a[0],
                                    height1: 1 * a[1],
                                    height2: 1 * a[1]
                                }
                                    , n = e.attr("data-lazy-image_detect");
                                if ("xs" === plp.screen) {
                                    var c = e.attr("data-lazy-image_detect-xs");
                                    c && (n = c)
                                }
                                if ("css-width" === n)
                                    i.width2 = e.width(),
                                    i.width2 < i.width1 && (i.height2 = i.width2 / i.width1 * i.height1);
                                else if ("css-width-height" === n)
                                    i.width2 = e.width(),
                                        i.height2 = e.height();
                                else if ("css-max-height" === n) {
                                    var o = parseInt(e.css("max-height"));
                                    i.height1 > o ? (i.height2 = o,
                                        i.width2 = o / i.height1 * i.width1) : e.css("max-height", i.height2)
                                } else if ("css-max-width-max-height" === n) {
                                    var s = parseInt(e.css("max-width"))
                                        , d = parseInt(e.css("max-height"));
                                    i.width2 > s && (i.width2 = s,
                                        i.height2 = s / i.width1 * i.height1),
                                    i.height2 > d && (i.width2 = d / i.height2 * i.width2,
                                        i.height2 = d),
                                    i.width2 < s && e.css("max-width", i.width2),
                                    i.height2 < d && e.css("max-height", i.height2)
                                } else if ("css-width-max-height" === n) {
                                    i.width2 = e.width(),
                                    i.width2 < i.width1 && (i.height2 = i.width2 / i.width1 * i.height1);
                                    var d = parseInt(e.css("max-height"));
                                    i.height2 > d ? i.height2 = d : e.css("max-height", i.height2)
                                } else
                                    "fill-width" === n && (i.width2 = e.parent().width(),
                                        i.height2 = i.width2 / i.width1 * i.height1);
                                l = t(l, i)
                            }
                            e.data(),
                                e.removeAttr("data-lazy-image"),
                                e.removeAttr("data-lazy-image_size"),
                                e.removeAttr("data-lazy-image_detect"),
                                e.removeAttr("data-lazy-image_nohd"),
                                e.removeAttr("data-lazy-image_noscale"),
                                e.addClass("lazy-loading"),
                                $("<img>").attr("src", l).on("load", function() {
                                    try {
                                        e.attr("src", l),
                                            e.removeClass("lazy-loading"),
                                            e.trigger("lazyload")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 15", arguments.callee)
                                    }
                                }).on("error", function() {
                                    try {
                                        e.removeClass("lazy-loading"),
                                            e.trigger("lazyerror")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 16", arguments.callee)
                                    }
                                })
                        } catch (p) {
                            error_handler(p, "libs_plp 14", arguments.callee)
                        }
                    }),
                    plp.lazy.add($("[data-lazy-bgimage]"), function(e) {
                        try {
                            var l = e.attr("data-lazy-bgimage");
                            if (r(l) && "true" !== e.attr("data-lazy-bgimage_noscale")) {
                                var a = e.attr("data-lazy-bgimage_size").split(",")
                                    , i = {
                                    retina: "true" !== e.attr("data-lazy-bgimage_nohd"),
                                    width1: 1 * a[0],
                                    width2: 1 * a[0],
                                    height1: 1 * a[1],
                                    height2: 1 * a[1]
                                }
                                    , n = e.width()
                                    , c = e.height()
                                    , o = e.css("background-size");
                                "cover" === o ? (i.width1 > n && (i.width2 = n,
                                    i.height2 = n / i.width1 * i.height1),
                                i.height2 < c && (i.height2 = c,
                                    i.width2 = c / i.height1 * i.width1)) : "contain" === o && (i.width2 > n && (i.width2 = n,
                                    i.height2 = n / i.width1 * i.height1),
                                i.height2 > c && (i.height2 = c,
                                    i.width2 = c / i.height1 * i.width1));
                                var l = t(l, i)
                            }
                            e.data(),
                                e.removeAttr("data-lazy-bgimage"),
                                e.removeAttr("data-lazy-bgimage_size"),
                                e.removeAttr("data-lazy-bgimage_nohd"),
                                e.removeAttr("data-lazy-bgimage_noscale"),
                                e.addClass("lazy-loading"),
                                $("<img>").attr("src", l).on("load", function() {
                                    try {
                                        e.css("background-image", 'url("' + l + '")'),
                                            e.removeClass("lazy-loading"),
                                            e.trigger("lazyload")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 18", arguments.callee)
                                    }
                                }).on("error", function() {
                                    try {
                                        e.removeClass("lazy-loading"),
                                            e.trigger("lazyerror")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 19", arguments.callee)
                                    }
                                })
                        } catch (s) {
                            error_handler(s, "libs_plp 17", arguments.callee)
                        }
                    }),
                    plp.lazy.add($("[data-lazy-all], .lazy-all"), function(e) {
                        try {
                            plp.lazy.force(e)
                        } catch (r) {
                            error_handler(r, "libs_plp 20", arguments.callee)
                        }
                    })
            } catch (l) {
                error_handler(l, "libs_plp 7", arguments.callee)
            }
        }),
        $(function() {
            try {
                plp.msg_error = function(e, r, t) {
                    try {
                        if ("xs" === plp.screen) {
                            var l = r ? e + "\n" + r : e;
                            return alert(l),
                                void (t && t())
                        }
                        return Modernizr.cssanimations ? swal({
                            title: e,
                            text: r || null,
                            type: "error"
                        }, t) : swal({
                            title: e,
                            text: r || null,
                            imageUrl: "//s.plpstatic.ru/swal/error.png"
                        }, t)
                    } catch (a) {
                        error_handler(a, "libs_plp 1", arguments.callee)
                    }
                }
                    ,
                    plp.msg_success = function(e, r, t) {
                        try {
                            if ("xs" === plp.screen) {
                                var l = r ? e + "\n" + r : e;
                                return alert(l),
                                    void (t && t())
                            }
                            return Modernizr.cssanimations ? swal({
                                title: e,
                                text: r || null,
                                type: "success"
                            }, t) : swal({
                                title: e,
                                text: r || null,
                                imageUrl: "//s.plpstatic.ru/swal/success.png"
                            }, t)
                        } catch (a) {
                            error_handler(a, "libs_plp 2", arguments.callee)
                        }
                    }
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }),
        $(function() {
            try {
                $("[data-ym_goal]").each(function() {
                    try {
                        var e = $(this)
                            , r = _.uniqueId("goal")
                            , t = e.data("ym_goal")
                            , l = function() {
                            try {
                                _.each(_.keys(window), function(e) {
                                    try {
                                        0 === e.indexOf("yaCounter") && window[e].reachGoal(t)
                                    } catch (r) {
                                        error_handler(r, "libs_plp 3", arguments.callee)
                                    }
                                })
                            } catch (e) {
                                error_handler(e, "libs_plp 2", arguments.callee)
                            }
                        };
                        e.on("click", function() {
                            try {
                                var t = e.hasClass("submit") && e.find(":submit").length
                                    , a = "send" === e.attr("data-action");
                                t || a ? $(this).closest("form.form, [data-form]").off(r).one("submit-success." + r, function() {
                                    try {
                                        l()
                                    } catch (e) {
                                        error_handler(e, "libs_plp 5", arguments.callee)
                                    }
                                }) : l()
                            } catch (i) {
                                error_handler(i, "libs_plp 4", arguments.callee)
                            }
                        })
                    } catch (a) {
                        error_handler(a, "libs_plp 1", arguments.callee)
                    }
                }),
                    $("[data-ga_category]").each(function() {
                        try {
                            var e = $(this)
                                , r = _.uniqueId("goal")
                                , t = e.data("ga_action")
                                , l = e.data("ga_category")
                                , a = function() {
                                try {
                                    window.ga && ga("send", "event", l, t),
                                    window.gtag && gtag("event", "generate_lead", {
                                        event_category: l,
                                        event_action: t
                                    })
                                } catch (e) {
                                    error_handler(e, "libs_plp 7", arguments.callee)
                                }
                            };
                            e.on("click", function() {
                                try {
                                    var t = e.hasClass("submit") && e.find(":submit").length
                                        , l = "send" === e.attr("data-action");
                                    t || l ? $(this).closest("form.form, [data-form]").off(r).one("submit-success." + r, function() {
                                        try {
                                            a()
                                        } catch (e) {
                                            error_handler(e, "libs_plp 9", arguments.callee)
                                        }
                                    }) : a()
                                } catch (i) {
                                    error_handler(i, "libs_plp 8", arguments.callee)
                                }
                            })
                        } catch (i) {
                            error_handler(i, "libs_plp 6", arguments.callee)
                        }
                    })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }),
        $(function() {
            try {
                var antiflood = {
                    last: 0,
                    interval: 2500
                }
                    , language = {
                    error: plp.l10n("Не удалось отправить форму!"),
                    validate: plp.l10n("Неправильно заполнены поля:"),
                    interval: plp.l10n("Пожалуйста, повторите отправку через пару секунд."),
                    required: plp.l10n("Поле «%field%» обязательно для заполнения."),
                    email: plp.l10n("Поле «%field%» должно содержать ваш настоящий e-mail адрес."),
                    phone: plp.l10n("Поле «%field%» должно содержать правильный номер телефона."),
                    number: plp.l10n("Поле «%field%» должно быть правильным числом."),
                    yes: plp.l10n("Да"),
                    no: plp.l10n("Нет")
                };
                $('.btn[data-action="send"], .btn-meta[data-action="send"]').each(function() {
                    try {
                        var e = $(this)
                            , r = e.closest("[data-form]");
                        if (!r.length)
                            return;
                        e.on("click", function() {
                            try {
                                r.trigger("submit")
                            } catch (e) {
                                error_handler(e, "libs_plp 2", arguments.callee)
                            }
                        }),
                        r.data("isquiz") === !1 && (r.on("submit", function() {
                            try {
                                e.prop("disabled", !0)
                            } catch (r) {
                                error_handler(r, "libs_plp 3", arguments.callee)
                            }
                        }),
                            r.on("submit-success submit-error submit-prevent", function() {
                                try {
                                    e.prop("disabled", !1)
                                } catch (r) {
                                    error_handler(r, "libs_plp 4", arguments.callee)
                                }
                            }))
                    } catch (t) {
                        error_handler(t, "libs_plp 1", arguments.callee)
                    }
                }),
                    $(".node[data-form]").each(function() {
                        try {
                            var $form = $(this);
                            $form.data("api-isQuiz", $form.data("isquiz")),
                                $form.data("api-name", $form.data("form").name),
                                $form.data("api-errors", []),
                                $form.on("submit-error", function() {
                                    try {
                                        $(creatium).triggerHandler("submit-error")
                                    } catch (e) {
                                        error_handler(e, "libs_plp 6", arguments.callee)
                                    }
                                }),
                                $form.on("submit-success", function(e, r, t) {
                                    try {
                                        $(creatium).triggerHandler("api-form-submit", [$form, r, t]),
                                            $.cookie("form_submitted", "1", {
                                                expires: 30
                                            })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 7", arguments.callee)
                                    }
                                }),
                                $form.on("keyup", function(e) {
                                    try {
                                        if ("TEXTAREA" === e.target.tagName)
                                            return;
                                        13 === e.keyCode && $form.trigger("submit")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 8", arguments.callee)
                                    }
                                });
                            var fields = []
                                , errors = []
                                , variables = {};
                            $form.on("input change", function() {
                                try {
                                    fields = [],
                                        errors = [],
                                        variables = {},
                                        $form.data("api-errors", errors),
                                        $form.data("api-$fields", $()),
                                        $form.find(".widget-field").each(function() {
                                            try {
                                                var $field = $(this);
                                                if ($field.closest("[data-form]")[0] !== $form[0])
                                                    return;
                                                $form.data("api-$fields", $form.data("api-$fields").add($field));
                                                var api_value = null;
                                                $field.data("api-value", api_value),
                                                    $field.data("api-disabledByCondition", !0);
                                                var vals = $field.find(".code").data("vals");
                                                vals || (vals = $field.find(".metahtml").data("vals"));
                                                var is_hidden = !1;
                                                if ($field.data("api-disabledManually"))
                                                    is_hidden = !0;
                                                else if (vals.condition)
                                                    try {
                                                        var scope = _.extend({
                                                            round: Math.round,
                                                            min: Math.min,
                                                            max: Math.max,
                                                            ceil: Math.ceil,
                                                            floor: Math.floor,
                                                            pow: Math.pow,
                                                            abs: Math.abs,
                                                            random: Math.random
                                                        }, variables);
                                                        with (scope)
                                                            is_hidden = !eval(vals.condition)
                                                    } catch (e) {
                                                        console.error("Condition error", e),
                                                            is_hidden = !1
                                                    }
                                                if (is_hidden && !$field.hasClass("is-hidden") && ($field.addClass("is-hidden"),
                                                    $field.triggerHandler("api-disable")),
                                                !is_hidden && $field.hasClass("is-hidden") && ($field.removeClass("is-hidden"),
                                                    $field.triggerHandler("api-enable")),
                                                    is_hidden)
                                                    return void (vals.variable && (variables[vals.variable] = 0));
                                                $field.data("api-disabledByCondition", !1);
                                                var $slide = $field.closest(".widget-form2 .swiper-slide");
                                                if ($slide.length) {
                                                    var $slides = $slide.parent().children()
                                                        , fieldSlideIndex = $slide.index()
                                                        , activeSlideIndex = $slides.filter(".swiper-slide-active").index();
                                                    if (activeSlideIndex < 0 && (activeSlideIndex = 0),
                                                    fieldSlideIndex > activeSlideIndex)
                                                        return
                                                }
                                                var field = {
                                                    name: vals.text,
                                                    type: vals.type,
                                                    required: vals.required,
                                                    id: vals.id,
                                                    value: null
                                                };
                                                if ("textarea" === vals.type)
                                                    field.value = $field.find("textarea").val(),
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("text" === vals.type)
                                                    field.value = $field.find("input").val(),
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("name" === vals.type)
                                                    field.value = $field.find("input").val(),
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("phone" === vals.type)
                                                    field.value = $field.find("input").val(),
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    field.value && !/.*\d.*\d.*\d.*\d.*/.test(field.value) && errors.push(["phone", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("email" === vals.type)
                                                    field.value = $field.find("input").val(),
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    field.value && !/.+@.+\..+/.test(field.value) && errors.push(["email", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("count" === vals.type)
                                                    field.value = 1 * $field.find("input").val() || 0,
                                                        api_value = field.value,
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("slider" === vals.type)
                                                    field.value = 1 * $field.find("input").val() || 0,
                                                        api_value = field.value,
                                                    vals.variable && (variables[vals.variable] = field.value);
                                                else if ("checkbox-list" === vals.type || "checkbox-visual" === vals.type) {
                                                    field.value = [],
                                                        api_value = {};
                                                    var indexes = [];
                                                    $field.find("input[type=checkbox]").each(function(e) {
                                                        try {
                                                            var r = $(this).prop("checked")
                                                                , t = vals.list[e].text;
                                                            r && (field.value.push(t),
                                                                indexes.push(e)),
                                                                api_value[t] = r
                                                        } catch (l) {
                                                            error_handler(l, "libs_plp 11", arguments.callee)
                                                        }
                                                    }),
                                                        field.value = field.value.join(", "),
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (variables[vals.variable] = 0,
                                                        indexes.forEach(function(e) {
                                                            try {
                                                                variables[vals.variable] += 1 * vals.list[e].value || 0
                                                            } catch (r) {
                                                                error_handler(r, "libs_plp 12", arguments.callee)
                                                            }
                                                        }))
                                                } else if ("checkbox-input" === vals.type) {
                                                    var checked = $field.find("input[type=checkbox]").prop("checked");
                                                    vals.required && !checked && errors.push(["required", field.name]),
                                                        field.value = checked ? language.yes : language.no,
                                                        api_value = checked,
                                                    vals.variable && (variables[vals.variable] = 1 * (checked ? vals.valueOn : vals.valueOff) || 0)
                                                } else if ("privacy-checkbox" === vals.type) {
                                                    var checked = $field.find("input[type=checkbox]").prop("checked");
                                                    vals.required && !checked && errors.push(["required", vals.privacy_checkbox.replace(/[<>]/g, "")]),
                                                        field.value = checked ? language.yes : language.no,
                                                        api_value = checked,
                                                    vals.variable && (variables[vals.variable] = 1 * (checked ? vals.valueOn : vals.valueOff) || 0)
                                                } else if ("radio-list" === vals.type || "radio-visual" === vals.type) {
                                                    var index = $field.find("input").index($field.find("input:checked"));
                                                    index >= 0 ? (field.value = vals.list[index].text,
                                                        api_value = field.value) : (field.value = "",
                                                        api_value = null,
                                                    vals.required && errors.push(["required", field.name])),
                                                    vals.variable && (index >= 0 ? variables[vals.variable] = vals.list[index].value : variables[vals.variable] = 0)
                                                } else if ("select-menu" === vals.type) {
                                                    var val = $field.find("select").val();
                                                    if ("" !== val) {
                                                        var index = 1 * val;
                                                        field.value = vals.list[index].text,
                                                            api_value = field.value
                                                    } else
                                                        api_value = null;
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && (index >= 0 ? variables[vals.variable] = vals.list[index].value : variables[vals.variable] = 0)
                                                } else if ("file" === vals.type)
                                                    field.value = $field.data("result"),
                                                        api_value = [field.value] || null,
                                                    vals.required && !field.value && errors.push(["required", field.name]);
                                                else if ("hidden" === vals.type)
                                                    field.value = $field.find("input").val(),
                                                        api_value = field.value;
                                                else if ("hackable" === vals.type) {
                                                    var hackable_value = $field.find("[plp-field]").attr("data-value");
                                                    "number" === vals.typing ? (api_value = 1 * hackable_value || 0,
                                                        field.value = api_value) : "boolean" === vals.typing ? (api_value = "1" === hackable_value || "true" === hackable_value,
                                                        field.value = hackable_value ? language.yes : language.no) : (api_value = hackable_value,
                                                        field.value = hackable_value),
                                                    vals.required && !field.value && errors.push(["required", field.name]),
                                                    vals.variable && ("boolean" === vals.typing ? variables[vals.variable] = 1 * (api_value ? vals.valueOn : vals.valueOff) || 0 : variables[vals.variable] = api_value)
                                                } else if ("result" === vals.type) {
                                                    var _result = 0;
                                                    try {
                                                        var scope = _.extend({
                                                            round: Math.round,
                                                            min: Math.min,
                                                            max: Math.max,
                                                            ceil: Math.ceil,
                                                            floor: Math.floor,
                                                            pow: Math.pow,
                                                            abs: Math.abs,
                                                            random: Math.random
                                                        }, variables);
                                                        with (scope)
                                                            _result = eval(vals.formula);
                                                        "number" == typeof _result && (_result = parseFloat(_result.toFixed(2))),
                                                        "undefined" == typeof _result && (_result = 0),
                                                        _.isNaN(_result) && (_result = 0)
                                                    } catch (e) {
                                                        console.error("Error in formula", e),
                                                            _result = 0
                                                    }
                                                    field.value = vals.format.replace("%result%", _result),
                                                        api_value = _result,
                                                        $field.find("[plp-field-result]").text(field.value),
                                                    vals.variable && (variables[vals.variable] = _result)
                                                } else {
                                                    if ("html" === vals.type) {
                                                        var scope = _.cloneDeep(variables)
                                                            , template = $field.data("template");
                                                        return template || (template = _.template(vals.template),
                                                            $field.data("template", template)),
                                                            void $field.find("[plp-field-template]").html(template(scope))
                                                    }
                                                    if ("privacy-button" === vals.type)
                                                        return;
                                                    if ("privacy-text" === vals.type)
                                                        return;
                                                    if ("cont" === vals.type)
                                                        return
                                                }
                                                fields.push(field);
                                                var api_validations = $field.data("api-validations") || [];
                                                api_validations.forEach(function(e) {
                                                    try {
                                                        e.cb(api_value) === !1 && errors.push(["custom", e.message])
                                                    } catch (r) {
                                                        error_handler(r, "libs_plp 13", arguments.callee)
                                                    }
                                                }),
                                                _.isEqual($field.data("api-value"), api_value) || ($field.data("api-value", api_value),
                                                    $field.triggerHandler("api-change"))
                                            } catch (jswrap_exception) {
                                                error_handler(jswrap_exception, "libs_plp 10", arguments.callee)
                                            }
                                        }),
                                        errors = errors.map(function(e) {
                                            try {
                                                return "custom" === e[0] ? e[1] : language[e[0]].replace("%field%", e[1])
                                            } catch (r) {
                                                error_handler(r, "libs_plp 14", arguments.callee)
                                            }
                                        })
                                } catch (jswrap_exception) {
                                    error_handler(jswrap_exception, "libs_plp 9", arguments.callee)
                                }
                            }),
                                setTimeout(function() {
                                    try {
                                        $form.trigger("input")
                                    } catch (e) {
                                        error_handler(e, "libs_plp 15", arguments.callee)
                                    }
                                }, 1),
                                $form.on("reset", function() {
                                    try {
                                        setTimeout(function() {
                                            try {
                                                $form.triggerHandler("input")
                                            } catch (e) {
                                                error_handler(e, "libs_plp 17", arguments.callee)
                                            }
                                        }, 1)
                                    } catch (e) {
                                        error_handler(e, "libs_plp 16", arguments.callee)
                                    }
                                }),
                                $form.on("validate", function(e, r) {
                                    try {
                                        $form.trigger("input"),
                                            errors.length > 0 ? ($form.trigger("submit-error"),
                                                plp.msg_error(language.validate, errors.join("\n"))) : r()
                                    } catch (t) {
                                        error_handler(t, "libs_plp 18", arguments.callee)
                                    }
                                }),
                                $form.on("submit", function(e) {
                                    try {
                                        if (e.stopPropagation(),
                                            $form.triggerHandler("input"),
                                        errors.length > 0)
                                            return $form.trigger("submit-error"),
                                                void plp.msg_error(language.validate, errors.join("\n"));
                                        if ($form.data("isquiz")) {
                                            var r = $form.find("[plp-form-container]").first().find("> .swiper-wrapper > .swiper-slide");
                                            if (r.filter(".swiper-slide-next").length)
                                                return void $form.trigger("slidenext")
                                        }
                                        if ($.now() - antiflood.interval < antiflood.last)
                                            return void plp.msg_error(language.error, language.interval);
                                        var t = $form.data("form")
                                            , l = plp.closest($form, '[data-modal="cart"]').length ? plp.cart.list : null
                                            , a = $form.closest("[data-item]").data("item");
                                        $(creatium).triggerHandler("api-before-form-submit", [$form, fields]);
                                        var i = {
                                            hit: {
                                                page_id: plp.page_id,
                                                ab_id: plp.content_id,
                                                visit_id: $.cookie("visit_id"),
                                                referer: document.referrer,
                                                uri: location.pathname + location.search
                                            },
                                            form: _.extend(t, {
                                                sequence: t.sequence || "stepwise",
                                                name: $form.data("api-name")
                                            }),
                                            item: a || [],
                                            items: l || [],
                                            fields: fields
                                        };
                                        if ($form.data("api-prevent") === !0)
                                            return $form.data("api-prevent", !1),
                                                void $form.triggerHandler("submit-prevent");
                                        var n = function(e, r, n) {
                                            try {
                                                if (0 === e.result)
                                                    $form.trigger("submit-error"),
                                                        plp.msg_error(language.error, e.errors);
                                                else if (1 === e.result) {
                                                    $form.triggerHandler("api-submit", [e.order_id, fields]),
                                                        $form.triggerHandler("submit-success", [e.order_id, fields]);
                                                    var c = {
                                                        name: "",
                                                        phone: "",
                                                        email: "",
                                                        count: "",
                                                        fields: {},
                                                        item: {},
                                                        send: i,
                                                        items: []
                                                    };
                                                    if (_.each(fields, function(e) {
                                                        try {
                                                            "" === c[e.type] && (c[e.type] = e.value),
                                                            c.fields[e.name] || (c.fields[e.name] = e.value)
                                                        } catch (r) {
                                                            error_handler(r, "libs_plp 21", arguments.callee)
                                                        }
                                                    }),
                                                        _.each(a, function(e) {
                                                            try {
                                                                c.item[e.type] || (c.item[e.type] = _.escape(e.value))
                                                            } catch (r) {
                                                                error_handler(r, "libs_plp 22", arguments.callee)
                                                            }
                                                        }),
                                                        _.each(l, function(e, r) {
                                                            try {
                                                                c.items[r] = {},
                                                                    _.each(e, function(e) {
                                                                        try {
                                                                            if (!c.items[r][e.type]) {
                                                                                var t;
                                                                                t = "amount" === e.type || "photo" === e.type ? e.value : _.escape(e.value),
                                                                                    c.items[r][e.type] = t
                                                                            }
                                                                        } catch (l) {
                                                                            error_handler(l, "libs_plp 24", arguments.callee)
                                                                        }
                                                                    })
                                                            } catch (t) {
                                                                error_handler(t, "libs_plp 23", arguments.callee)
                                                            }
                                                        }),
                                                        _.extend(c, e),
                                                        console.log("Form data", {
                                                            time: e.time,
                                                            name: e.name,
                                                            email: e.email,
                                                            phone: e.phone,
                                                            count: e.count,
                                                            fields: e.fields,
                                                            item: e.item,
                                                            items: e.items
                                                        }),
                                                    "msg" === t.after)
                                                        plp.msg_success(_.template(t.msg, c), null);
                                                    else if ("url" === t.after)
                                                        location.href = _.template(t.url, c);
                                                    else if ("addhtml" === t.after)
                                                        $("body").append(_.template(t.addhtml, c));
                                                    else if ("pay" === t.after)
                                                        e.url ? location.href = e.url : e.form && $(e.form).hide().appendTo("body").submit();
                                                    else if ("msg+url" === t.after) {
                                                        var o = function() {
                                                            try {
                                                                location.href = _.template(t.url, c)
                                                            } catch (e) {
                                                                error_handler(e, "libs_plp 25", arguments.callee)
                                                            }
                                                        };
                                                        plp.msg_success(_.template(t.msg, c), null, function() {
                                                            try {
                                                                "stepwise" === t.sequence && o()
                                                            } catch (e) {
                                                                error_handler(e, "libs_plp 26", arguments.callee)
                                                            }
                                                        }),
                                                            "simultaneous" === t.sequence ? o() : "delayed3sec" === t.sequence ? setTimeout(o, 3e3) : "delayed5sec" === t.sequence ? setTimeout(o, 5e3) : "delayed10sec" === t.sequence && setTimeout(o, 1e4)
                                                    } else if ("msg+pay" === t.after) {
                                                        var o = function() {
                                                            try {
                                                                e.url ? location.href = e.url : e.form && $(e.form).hide().appendTo("body").submit()
                                                            } catch (r) {
                                                                error_handler(r, "libs_plp 27", arguments.callee)
                                                            }
                                                        };
                                                        plp.msg_success(_.template(t.msg, c), null, function() {
                                                            try {
                                                                "stepwise" === t.sequence && o()
                                                            } catch (e) {
                                                                error_handler(e, "libs_plp 28", arguments.callee)
                                                            }
                                                        }),
                                                            "simultaneous" === t.sequence ? o() : "delayed3sec" === t.sequence ? setTimeout(o, 3e3) : "delayed5sec" === t.sequence ? setTimeout(o, 5e3) : "delayed10sec" === t.sequence && setTimeout(o, 1e4)
                                                    } else if ("msg+addhtml" === t.after) {
                                                        var o = function() {
                                                            try {
                                                                $("body").append(_.template(t.addhtml, c))
                                                            } catch (e) {
                                                                error_handler(e, "libs_plp 29", arguments.callee)
                                                            }
                                                        };
                                                        plp.msg_success(_.template(t.msg, c), null, function() {
                                                            try {
                                                                "stepwise" === t.sequence && o()
                                                            } catch (e) {
                                                                error_handler(e, "libs_plp 30", arguments.callee)
                                                            }
                                                        }),
                                                            "simultaneous" === t.sequence ? o() : "delayed3sec" === t.sequence ? setTimeout(o, 3e3) : "delayed5sec" === t.sequence ? setTimeout(o, 5e3) : "delayed10sec" === t.sequence && setTimeout(o, 1e4)
                                                    } else
                                                        "js" === t.after && (jscode = "(function (data) {with (data) {" + t.js + "}})(<%= data %>);",
                                                            $.globalEval(_.template(jscode, {
                                                                data: JSON.stringify(c)
                                                            })));
                                                    $form.trigger("reset"),
                                                    l && l.length && plp.cart.empty(),
                                                        plp.modal.closeAll(),
                                                        send_last = $.now()
                                                } else
                                                    $form.trigger("submit-error"),
                                                        plp.msg_error(language.error, null)
                                            } catch (s) {
                                                error_handler(s, "libs_plp 20", arguments.callee)
                                            }
                                        };
                                        $.ajax("/handler.php", {
                                            type: "POST",
                                            data: JSON.stringify(i),
                                            dataType: "json",
                                            contentType: "application/json",
                                            processData: !1,
                                            success: n,
                                            error: n
                                        })
                                    } catch (c) {
                                        error_handler(c, "libs_plp 19", arguments.callee)
                                    }
                                })
                        } catch (jswrap_exception) {
                            error_handler(jswrap_exception, "libs_plp 5", arguments.callee)
                        }
                    })
            } catch (jswrap_exception) {
                error_handler(jswrap_exception, "libs_plp 0", arguments.callee)
            }
        }),
        plp._screen = function() {
            try {
                if (plp.screen)
                    return;
                var e = document.body.clientWidth
                    , r = plp.screenSizes && plp.screenSizes.sm || 768
                    , t = plp.screenSizes && plp.screenSizes.md || 992
                    , l = plp.screenSizes && plp.screenSizes.lg || 1200
                    , a = r - 1
                    , i = t - 1
                    , n = l - 1;
                "screens-xs" === plp.screens ? plp.screen = "xs" : "screens-sm" === plp.screens ? plp.screen = "sm" : "screens-md" === plp.screens ? plp.screen = "md" : "screens-lg" === plp.screens ? plp.screen = "lg" : "screens-xs-sm" === plp.screens ? e > r ? plp.screen = "sm" : e <= a && (plp.screen = "xs") : "screens-xs-md" === plp.screens ? e > t ? plp.screen = "md" : e <= i && (plp.screen = "xs") : "screens-xs-lg" === plp.screens ? e > l ? plp.screen = "lg" : e <= n && (plp.screen = "xs") : "screens-sm-md" === plp.screens ? e > t ? plp.screen = "md" : e <= i && (plp.screen = "sm") : "screens-sm-lg" === plp.screens ? e > l ? plp.screen = "lg" : e <= n && (plp.screen = "sm") : "screens-md-lg" === plp.screens ? e > l ? plp.screen = "lg" : e <= n && (plp.screen = "md") : "screens-xs-sm-md" === plp.screens ? e > t ? plp.screen = "md" : e > r && e <= i ? plp.screen = "sm" : e <= a && (plp.screen = "xs") : "screens-xs-sm-lg" === plp.screens ? e > l ? plp.screen = "lg" : e > r && e <= n ? plp.screen = "sm" : e <= a && (plp.screen = "xs") : "screens-xs-md-lg" === plp.screens ? e > l ? plp.screen = "lg" : e > t && e <= n ? plp.screen = "md" : e <= i && (plp.screen = "xs") : "screens-sm-md-lg" === plp.screens ? e > l ? plp.screen = "lg" : e > t && e <= n ? plp.screen = "md" : e <= i && (plp.screen = "sm") : "screens-xs-sm-md-lg" === plp.screens && (e > l ? plp.screen = "lg" : e > t && e <= n ? plp.screen = "md" : e > r && e <= i ? plp.screen = "sm" : e <= a && (plp.screen = "xs")),
                    [].slice.call(document.body.childNodes).forEach(function(e) {
                        try {
                            e.className && e.className.indexOf("area") >= 0 && e.classList.add("screen-" + plp.screen)
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    })
            } catch (c) {
                error_handler(c, "libs_plp 0", arguments.callee)
            }
        }
        ,
        $(function() {
            try {
                plp._screen(),
                    $("script.adaptive").each(function() {
                        try {
                            var e = $(this).parent().contents()
                                , r = e[e.index(this) + 1];
                            8 === r.nodeType && r.parentNode.removeChild(r),
                                this.parentNode.removeChild(this)
                        } catch (t) {
                            error_handler(t, "libs_plp 3", arguments.callee)
                        }
                    })
            } catch (e) {
                error_handler(e, "libs_plp 2", arguments.callee)
            }
        }),
        $(function() {
            try {
                $(".node[bgparticles]").each(function() {
                    try {
                        var e = $(this)
                            , r = JSON.parse(e.attr("bgparticles"));
                        e.removeAttr("bgparticles"),
                            e.find(".particles-js-canvas-el").remove();
                        var t = e.find(">.wrapper1")
                            , l = particlesJS(t.get(0), r);
                        l.canvas.el.style.borderRadius = t.css("border-radius"),
                            l.interactivity.events.onclick.handler = function(e) {
                                try {
                                    var r = $(e.target);
                                    if (r.parents(".modal.in").length)
                                        return this.canvas.el === r.parentsUntil(".cont").parent().find(".particles-js-canvas-el").get(0)
                                } catch (t) {
                                    error_handler(t, "libs_plp 2", arguments.callee)
                                }
                            }
                    } catch (a) {
                        error_handler(a, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (e) {
                error_handler(e, "libs_plp 0", arguments.callee)
            }
        }),
        $(function() {
            try {
                var e = !1
                    , r = $("<div></div>")
                    , t = $(".section.fixation-top:visible:first")
                    , l = t.attr("data-opacity");
                t.length && $(document).on("ready scroll", function(a) {
                    try {
                        var i = $(document).scrollTop();
                        if (e)
                            n = r.offset().top,
                            i <= n && (r.remove(),
                                t.css("opacity", 1),
                                t.removeClass("fixed"),
                                t.triggerHandler("fixation-change"),
                                e = !1);
                        else {
                            var n = t.offset().top;
                            i > n && (r.css("height", t.height()).insertAfter(t),
                                t.css("opacity", l),
                                t.addClass("fixed"),
                                t.triggerHandler("fixation-change"),
                                e = !0)
                        }
                    } catch (c) {
                        error_handler(c, "libs_plp 1", arguments.callee)
                    }
                })
            } catch (a) {
                error_handler(a, "libs_plp 0", arguments.callee)
            }
        }),
        $(function() {
            try {
                var e = !1
                    , r = $("<div></div>")
                    , t = $(".section.fixation-bottom:visible:first")
                    , l = t.attr("data-opacity");
                if (t.length) {
                    if (t.next().hasClass("section-helper"))
                        return t.css("opacity", l),
                            t.addClass("fixed"),
                            void t.triggerHandler("fixation-change");
                    $(document).on("ready scroll", function(a) {
                        try {
                            var i = $(document).scrollTop() + $(window).height();
                            if (e) {
                                var n = r.offset().top + t.outerHeight();
                                i < n && (r.remove(),
                                    t.css("opacity", 1),
                                    t.removeClass("fixed"),
                                    t.triggerHandler("fixation-change"),
                                    e = !1)
                            } else {
                                var n = t.offset().top + t.outerHeight();
                                i > n && (r.insertAfter(t),
                                    t.css("opacity", l),
                                    t.addClass("fixed"),
                                    t.triggerHandler("fixation-change"),
                                    e = !0)
                            }
                        } catch (c) {
                            error_handler(c, "libs_plp 3", arguments.callee)
                        }
                    })
                }
            } catch (a) {
                error_handler(a, "libs_plp 2", arguments.callee)
            }
        }),
        $(function() {
            try {
                var e = function(r) {
                    try {
                        e.started !== !0 && ($.getScript("https://api-maps.yandex.ru/2.1/?lang=ru-RU"),
                            e.started = !0),
                            window.ymaps ? ymaps.ready(r) : setTimeout(function() {
                                try {
                                    e(r)
                                } catch (t) {
                                    error_handler(t, "libs_plp 2", arguments.callee)
                                }
                            }, 250)
                    } catch (t) {
                        error_handler(t, "libs_plp 1", arguments.callee)
                    }
                }
                    , r = function(e) {
                    try {
                        r.started !== !0 && ($.getScript("https://maps.googleapis.com/maps/api/js?key=AIzaSyAldqEbYQZJSOeNYP1pDzg3Zx499U4NVAU&language=ru&libraries=places"),
                            r.started = !0),
                            window.google ? e() : setTimeout(function() {
                                try {
                                    r(e)
                                } catch (t) {
                                    error_handler(t, "libs_plp 4", arguments.callee)
                                }
                            }, 250)
                    } catch (t) {
                        error_handler(t, "libs_plp 3", arguments.callee)
                    }
                };
                $(".macros-map-new").each(function() {
                    try {
                        var t = $(this).children(".map")
                            , l = t.data("service");
                        t.data("params");
                        "yandex" === l ? plp.lazy.add(t, function() {
                            try {
                                e(function() {
                                    try {
                                        var e = t.data("params")
                                            , r = new ymaps.Map(t.attr("id"),{
                                            center: e.center,
                                            type: e.type,
                                            zoom: e.zoom,
                                            controls: []
                                        });
                                        r.behaviors.disable(["scrollZoom"]);
                                        var l = new ymaps.GeoObject({
                                            geometry: {
                                                type: "Point",
                                                coordinates: e.point
                                            }
                                        },{
                                            draggable: !1
                                        });
                                        r.geoObjects.add(l),
                                            r.controls.add("zoomControl", {
                                                "float": "left",
                                                position: {
                                                    left: 10,
                                                    top: 10
                                                }
                                            }).add("typeSelector", {
                                                "float": "right"
                                            })
                                    } catch (a) {
                                        error_handler(a, "libs_plp 7", arguments.callee)
                                    }
                                })
                            } catch (r) {
                                error_handler(r, "libs_plp 6", arguments.callee)
                            }
                        }) : "google" === l && plp.lazy.add(t, function() {
                            try {
                                r(function() {
                                    try {
                                        var e = t.data("params")
                                            , r = new google.maps.Map(t[0],{
                                            zoom: e.zoom,
                                            center: new google.maps.LatLng(e.center[0],e.center[1]),
                                            mapTypeId: e.type,
                                            fullscreenControl: !0,
                                            rotateControl: !0,
                                            streetViewControl: !1,
                                            scrollwheel: !1
                                        });
                                        new google.maps.Marker({
                                            position: new google.maps.LatLng(e.point[0],e.point[1]),
                                            map: r,
                                            draggable: !1
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 9", arguments.callee)
                                    }
                                })
                            } catch (e) {
                                error_handler(e, "libs_plp 8", arguments.callee)
                            }
                        })
                    } catch (a) {
                        error_handler(a, "libs_plp 5", arguments.callee)
                    }
                })
            } catch (t) {
                error_handler(t, "libs_plp 0", arguments.callee)
            }
        }),
        window.creatium = plp,
        window.cr = plp,
        function() {
            try {
                var e = creatium.api && creatium.api.queue;
                creatium.api = function(e, r) {
                    try {
                        if (e instanceof Function && (r = e,
                            e = "v1"),
                        "v1" !== e)
                            throw new Error("Unknown API version");
                        r(creatium.api.v1.Page.create())
                    } catch (t) {
                        error_handler(t, "libs_plp 1", arguments.callee)
                    }
                }
                    ,
                    creatium.api.init = _.once(function() {
                        try {
                            e.forEach(function(e) {
                                try {
                                    creatium.api(e[0], e[1])
                                } catch (r) {
                                    error_handler(r, "libs_plp 3", arguments.callee)
                                }
                            }),
                                creatium.api.initialized = !0,
                                $(creatium).triggerHandler("api-init")
                        } catch (r) {
                            error_handler(r, "libs_plp 2", arguments.callee)
                        }
                    }),
                    creatium.api.v1 = {},
                    creatium.api.v1.factory = function(e, r, t, l, a) {
                        try {
                            var i = {};
                            e.forEach(function(e) {
                                try {
                                    _.each(e.methods, function(e, r) {
                                        try {
                                            if (i.hasOwnProperty(r))
                                                throw new Error("Property " + r + " already exists");
                                            i[r] = e
                                        } catch (t) {
                                            error_handler(t, "libs_plp 6", arguments.callee)
                                        }
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 5", arguments.callee)
                                }
                            });
                            var n = Object.create(i);
                            return Object.defineProperty(n, "classes", {
                                value: _.without(_.map(e, "name"), "Emmiter")
                            }),
                                e.forEach(function(e) {
                                    try {
                                        e.initialize.call(n, r, t, l, a)
                                    } catch (i) {
                                        error_handler(i, "libs_plp 7", arguments.callee)
                                    }
                                }),
                                n
                        } catch (c) {
                            error_handler(c, "libs_plp 4", arguments.callee)
                        }
                    }
                    ,
                    creatium.api.v1.defineLazyProperty = function(e, r, t) {
                        try {
                            Object.defineProperty(e, r, {
                                configurable: !0,
                                get: function() {
                                    try {
                                        var l = t.call(this);
                                        return Object.defineProperty(e, r, {
                                            configurable: !1,
                                            value: l
                                        }),
                                            l
                                    } catch (a) {
                                        error_handler(a, "libs_plp 9", arguments.callee)
                                    }
                                }
                            })
                        } catch (l) {
                            error_handler(l, "libs_plp 8", arguments.callee)
                        }
                    }
                    ,
                    Object.defineProperty(window, "_page", {
                        configurable: !0,
                        get: function() {
                            try {
                                var e = !1
                                    , r = document.createElement("console-api-initiation");
                                if (Object.defineProperty(r, "id", {
                                    get: function() {
                                        try {
                                            e = !0
                                        } catch (r) {
                                            error_handler(r, "libs_plp 11", arguments.callee)
                                        }
                                    }
                                }),
                                    console.dir(r),
                                    e)
                                    return Object.defineProperty(window, "_page", {
                                        value: creatium.api.v1.Page.create()
                                    }),
                                        window._page;
                                throw new Error("_page доступен только в консоли браузера")
                            } catch (t) {
                                error_handler(t, "libs_plp 10", arguments.callee)
                            }
                        }
                    })
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(),
        function(e) {
            try {
                e.Button = {
                    name: "Button",
                    initialize: function(e) {
                        try {
                            Object.defineProperty(this, "isActive", {
                                get: function() {
                                    try {
                                        return e.find(".btn, .btn-meta").hasClass("active")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 2", arguments.callee)
                                    }
                                }
                            })
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: [],
                    methods: {
                        setActive: function(e) {
                            try {
                                e && !this.isActive && $(this.el).find(".btn, .btn-meta").addClass("active"),
                                !e && this.isActive && $(this.el).find(".btn, .btn-meta").removeClass("active")
                            } catch (r) {
                                error_handler(r, "libs_plp 3", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Cart = {
                    name: "Cart",
                    instance: null,
                    initialize: function() {
                        try {
                            Object.defineProperty(this, "items", {
                                get: function() {
                                    try {
                                        return creatium.cart.list.map(function(r) {
                                            try {
                                                return e.CartItem.create(r)
                                            } catch (t) {
                                                error_handler(t, "libs_plp 3", arguments.callee)
                                            }
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 2", arguments.callee)
                                    }
                                }
                            }),
                                Object.defineProperty(this, "subtotal", {
                                    get: function() {
                                        try {
                                            var e = 0;
                                            return _.each(creatium.cart.list, function(r) {
                                                try {
                                                    var t = 1 * _.filter(r, {
                                                        type: "amount"
                                                    })[0].value
                                                        , l = _.filter(r, {
                                                        type: "price"
                                                    })[0].value;
                                                    e += creatium.cart.getPrice(l) * t
                                                } catch (a) {
                                                    error_handler(a, "libs_plp 5", arguments.callee)
                                                }
                                            }),
                                                e
                                        } catch (r) {
                                            error_handler(r, "libs_plp 4", arguments.callee)
                                        }
                                    }
                                }),
                                $(creatium).on("api-cart-item-add", function(r, t) {
                                    try {
                                        e.Emmiter.emit(this, "item-add", null, {
                                            item: e.CartItem.create(t)
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 6", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                $(creatium).on("api-cart-item-remove", function(r, t) {
                                    try {
                                        e.Emmiter.emit(this, "item-remove", null, {
                                            item: e.CartItem.create(t)
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 7", arguments.callee)
                                    }
                                }
                                    .bind(this));
                            var r = this.subtotal;
                            $(creatium).on("cart-change", function(t, l) {
                                try {
                                    var a = this.subtotal;
                                    r !== a && (e.Emmiter.emit(this, "subtotal-change", null, {
                                        oldSubtotal: r,
                                        subtotal: a
                                    }),
                                        r = a)
                                } catch (i) {
                                    error_handler(i, "libs_plp 8", arguments.callee)
                                }
                            }
                                .bind(this))
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["subtotal-change", "item-add", "item-remove"],
                    methods: {
                        addItem: function(r) {
                            try {
                                var t = e.CartItem.create([{
                                    name: "Название товара",
                                    type: "title",
                                    value: r.title || "Новый товар"
                                }, {
                                    name: "Цена товара",
                                    type: "price",
                                    value: r.price || "400 руб."
                                }, {
                                    name: "Фото товара",
                                    type: "photo",
                                    value: r.image || null
                                }, {
                                    name: "Количество",
                                    type: "amount",
                                    value: r.quantity || 1
                                }]);
                                return creatium.cart.add(t._item, !0),
                                    t
                            } catch (l) {
                                error_handler(l, "libs_plp 9", arguments.callee)
                            }
                        },
                        removeItem: function(e) {
                            try {
                                if (creatium.cart.list.indexOf(e._item) < 0)
                                    return void console.error("Cart item is already removed");
                                creatium.cart.remove(e._item)
                            } catch (r) {
                                error_handler(r, "libs_plp 10", arguments.callee)
                            }
                        }
                    },
                    create: function() {
                        try {
                            return e.Cart.instance ? e.Cart.instance : (e.Cart.instance = e.factory([e.Emmiter, e.Cart]),
                                e.Cart.instance)
                        } catch (r) {
                            error_handler(r, "libs_plp 11", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.CartItem = {
                    name: "CartItem",
                    instances: [],
                    initialize: function(e) {
                        try {
                            Object.defineProperty(this, "_item", {
                                value: e
                            }),
                                Object.defineProperty(this, "title", {
                                    get: function() {
                                        try {
                                            var e = _.filter(this._item, {
                                                type: "title"
                                            })[0];
                                            return e.value
                                        } catch (r) {
                                            error_handler(r, "libs_plp 2", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "price", {
                                    get: function() {
                                        try {
                                            var e = _.filter(this._item, {
                                                type: "price"
                                            })[0];
                                            return e.value
                                        } catch (r) {
                                            error_handler(r, "libs_plp 3", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "quantity", {
                                    get: function() {
                                        try {
                                            var e = _.filter(this._item, {
                                                type: "amount"
                                            })[0];
                                            return e.value
                                        } catch (r) {
                                            error_handler(r, "libs_plp 4", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "image", {
                                    get: function() {
                                        try {
                                            var e = _.filter(this._item, {
                                                type: "photo"
                                            })[0];
                                            return e.value || null
                                        } catch (r) {
                                            error_handler(r, "libs_plp 5", arguments.callee)
                                        }
                                    }
                                })
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: [],
                    methods: {
                        setTitle: function(e) {
                            try {
                                var r = _.filter(this._item, {
                                    type: "title"
                                })[0];
                                r.value = e,
                                    $(creatium).triggerHandler("cart-change"),
                                    plp.cart.update()
                            } catch (t) {
                                error_handler(t, "libs_plp 6", arguments.callee)
                            }
                        },
                        setPrice: function(e) {
                            try {
                                var r = _.filter(this._item, {
                                    type: "price"
                                })[0];
                                r.value = e,
                                    $(creatium).triggerHandler("cart-change"),
                                    plp.cart.update()
                            } catch (t) {
                                error_handler(t, "libs_plp 7", arguments.callee)
                            }
                        },
                        setQuantity: function(e) {
                            try {
                                var r = _.filter(this._item, {
                                    type: "amount"
                                })[0];
                                r.value = e,
                                    $(creatium).triggerHandler("cart-change"),
                                    plp.cart.update()
                            } catch (t) {
                                error_handler(t, "libs_plp 8", arguments.callee)
                            }
                        },
                        setImage: function(e) {
                            try {
                                var r = _.filter(this._item, {
                                    type: "photo"
                                })[0];
                                r.value = e,
                                    $(creatium).triggerHandler("cart-change"),
                                    plp.cart.update()
                            } catch (t) {
                                error_handler(t, "libs_plp 9", arguments.callee)
                            }
                        }
                    },
                    create: function(r) {
                        try {
                            var t = e.CartItem.instances.find(function(e) {
                                try {
                                    return e._item === r
                                } catch (t) {
                                    error_handler(t, "libs_plp 11", arguments.callee)
                                }
                            });
                            return t ? t : (t = e.factory([e.CartItem], r),
                                e.CartItem.instances.push(t),
                                t)
                        } catch (l) {
                            error_handler(l, "libs_plp 10", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Component = {
                    name: "Component",
                    initialize: function(e) {
                        try {
                            Object.defineProperty(this, "el", {
                                value: e[0]
                            })
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: [],
                    methods: {
                        getComponentsByClass: function(r) {
                            try {
                                return e.Page.instance.getComponentsByClass(r, this.el)
                            } catch (t) {
                                error_handler(t, "libs_plp 2", arguments.callee)
                            }
                        },
                        show: function() {
                            try {
                                $(this.el).show()
                            } catch (e) {
                                error_handler(e, "libs_plp 3", arguments.callee)
                            }
                        },
                        hide: function() {
                            try {
                                $(this.el).hide()
                            } catch (e) {
                                error_handler(e, "libs_plp 4", arguments.callee)
                            }
                        }
                    },
                    create: function(r) {
                        try {
                            var t = r.data("api.Component");
                            if (t)
                                return t;
                            if (!r.hasClass("node"))
                                return null;
                            r.hasClass("widget-form") && console.error("Предупреждение: Старые формы не подключены к API");
                            var l = [e.Emmiter, e.Component];
                            return r[0].classList.contains("section") && l.push(e.Section),
                            r[0].classList.contains("section-slider") && l.push(e.Slider),
                            r[0].classList.contains("widget-slider") && l.push(e.Slider),
                            r[0].classList.contains("widget-tabs") && l.push(e.Slider),
                            r[0].classList.contains("widget-spoiler") && l.push(e.Spoiler),
                            r[0].classList.contains("widget-countdown") && l.push(e.Countdown),
                            r[0].classList.contains("widget-form2") && l.push(e.Form),
                            r[0].classList.contains("widget-field") && l.push(e.Field),
                            r[0].classList.contains("widget-button") && l.push(e.Button),
                            r[0].classList.contains("widget-menu-button") && l.push(e.Button),
                            r[0].classList.contains("widget-hover") && l.push(e.Hover),
                                t = e.factory(l, r),
                                r.data("api.Component", t),
                                t
                        } catch (a) {
                            error_handler(a, "libs_plp 5", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Countdown = {
                    name: "Countdown",
                    initialize: function(r) {
                        try {
                            Object.defineProperty(this, "isExpired", {
                                get: function() {
                                    try {
                                        return $(this.el).data("api-expired") === !0
                                    } catch (e) {
                                        error_handler(e, "libs_plp 2", arguments.callee)
                                    }
                                }
                            }),
                                Object.defineProperty(this, "until", {
                                    get: function() {
                                        try {
                                            return $(this.el).data("api-until")
                                        } catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    }
                                }),
                                r.on("api-tick", function() {
                                    try {
                                        e.Emmiter.emit(this, "tick")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("api-expiry", function() {
                                    try {
                                        e.Emmiter.emit(this, "expiry")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["tick", "expiry"],
                    methods: {
                        setUntil: function(e) {
                            try {
                                $(this.el).data("api-setUntil")(e)
                            } catch (r) {
                                error_handler(r, "libs_plp 6", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Emmiter = {
                    name: "Emmiter",
                    initialize: function() {
                        try {
                            Object.defineProperty(this, "_events", {
                                value: {}
                            }),
                                this.classes.forEach(function(r) {
                                    try {
                                        e[r].events && e[r].events.forEach(function(e) {
                                            try {
                                                Object.defineProperty(this._events, e, {
                                                    value: []
                                                })
                                            } catch (r) {
                                                error_handler(r, "libs_plp 3", arguments.callee)
                                            }
                                        }
                                            .bind(this))
                                    } catch (t) {
                                        error_handler(t, "libs_plp 2", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    methods: {
                        on: function(e, r) {
                            try {
                                this._events[e] ? this._events[e].push(r) : console.warn('Предупреждение: События "' + e + '" не существует.')
                            } catch (t) {
                                error_handler(t, "libs_plp 4", arguments.callee)
                            }
                        },
                        once: function(e, r) {
                            try {
                                this.on(e, function l() {
                                    try {
                                        this.off(e, l),
                                            r.apply(this, [].slice.call(arguments, 0))
                                    } catch (t) {
                                        error_handler(t, "libs_plp 6", arguments.callee)
                                    }
                                }
                                    .bind(this))
                            } catch (t) {
                                error_handler(t, "libs_plp 5", arguments.callee)
                            }
                        },
                        off: function(e, r) {
                            try {
                                this._events[e] && this._events[e].splice(this._events[e].indexOf(r) >>> 0, 1)
                            } catch (t) {
                                error_handler(t, "libs_plp 7", arguments.callee)
                            }
                        }
                    },
                    emit: function(r, t, l, a) {
                        try {
                            if (!r._events[t])
                                throw new Error("No such event");
                            l = l || {};
                            var i = e.Event.create(t, {
                                prevent: l.prevent || _.noop,
                                isPrevented: l.isPrevented === !0
                            }, a);
                            r._events[t].slice().map(function(e) {
                                try {
                                    try {
                                        e.call(r, i)
                                    } catch (t) {
                                        console.error(t)
                                    }
                                    l.intermediate && l.intermediate.call(r, i)
                                } catch (a) {
                                    error_handler(a, "libs_plp 9", arguments.callee)
                                }
                            })
                        } catch (n) {
                            error_handler(n, "libs_plp 8", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Event = {
                    name: "Event",
                    initialize: function(e, r, t) {
                        try {
                            _.each(t || {}, function(e, r) {
                                try {
                                    Object.defineProperty(this, r, {
                                        value: e
                                    })
                                } catch (t) {
                                    error_handler(t, "libs_plp 2", arguments.callee)
                                }
                            }, this),
                                Object.defineProperty(this, "type", {
                                    value: e
                                }),
                                Object.defineProperty(this, "cancelable", {
                                    value: r.prevent instanceof Function
                                }),
                                Object.defineProperty(this, "isPrevented", {
                                    configurable: !0,
                                    value: r.isPrevented || !1
                                }),
                                Object.defineProperty(this, "prevent", {
                                    value: function() {
                                        try {
                                            if (!this.cancelable || this.isPrevented)
                                                return;
                                            r.prevent(),
                                                Object.defineProperty(this, "isPrevented", {
                                                    value: !0
                                                })
                                        } catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    }
                                        .bind(this)
                                })
                        } catch (l) {
                            error_handler(l, "libs_plp 1", arguments.callee)
                        }
                    },
                    methods: {},
                    create: function(r, t, l) {
                        try {
                            return e.factory([e.Event], r, t, l)
                        } catch (a) {
                            error_handler(a, "libs_plp 4", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Field = {
                    name: "Field",
                    initialize: function(r) {
                        try {
                            Object.defineProperty(this, "form", {
                                value: e.Page.instance.getComponent(r.closest(".widget-form2")[0])
                            }),
                                Object.defineProperty(this, "el", {
                                    value: r[0]
                                });
                            var t = r.find(".metahtml > .code").data("vals");
                            Object.defineProperty(this, "name", {
                                value: t.text
                            }),
                                Object.defineProperty(this, "type", {
                                    value: function() {
                                        try {
                                            return "name" === t.type ? "name" : "phone" === t.type ? "phone" : "email" === t.type ? "email" : void 0
                                        } catch (e) {
                                            error_handler(e, "libs_plp 2", arguments.callee)
                                        }
                                    }()
                                }),
                                Object.defineProperty(this, "uid", {
                                    value: t.id
                                }),
                                Object.defineProperty(this, "variable", {
                                    value: t.variable
                                }),
                                Object.defineProperty(this, "isRequired", {
                                    value: t.required
                                }),
                                Object.defineProperty(this, "hasCondition", {
                                    value: t.condition.length
                                }),
                                Object.defineProperty(this, "value", {
                                    get: function() {
                                        try {
                                            return r.data("api-value")
                                        } catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "isDisabled", {
                                    get: function() {
                                        try {
                                            return r.data("api-disabledManually") || r.data("api-disabledByCondition")
                                        } catch (e) {
                                            error_handler(e, "libs_plp 4", arguments.callee)
                                        }
                                    }
                                }),
                                r.on("api-disable", function() {
                                    try {
                                        e.Emmiter.emit(this, "disable")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("api-enable", function() {
                                    try {
                                        e.Emmiter.emit(this, "enable")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 6", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("api-change", function() {
                                    try {
                                        e.Emmiter.emit(this, "change")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 7", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (l) {
                            error_handler(l, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["change", "disable", "enable"],
                    methods: {
                        disable: function() {
                            try {
                                $(this.el).data("api-disabledManually", !0),
                                    $(this.form.el).triggerHandler("input")
                            } catch (e) {
                                error_handler(e, "libs_plp 8", arguments.callee)
                            }
                        },
                        enable: function() {
                            try {
                                $(this.el).data("api-disabledManually", !0),
                                    $(this.form.el).triggerHandler("input")
                            } catch (e) {
                                error_handler(e, "libs_plp 9", arguments.callee)
                            }
                        },
                        setValue: function(e) {
                            try {
                                var r = $(this.el).data("api-setValue");
                                r && r(e),
                                this.form.__redrawRequested || (this.form.__redrawRequested = !0,
                                    window.requestAnimationFrame(function() {
                                        try {
                                            $(this.form.el).triggerHandler("input"),
                                                delete this.form.__redrawRequested
                                        } catch (e) {
                                            error_handler(e, "libs_plp 11", arguments.callee)
                                        }
                                    }
                                        .bind(this)))
                            } catch (t) {
                                error_handler(t, "libs_plp 10", arguments.callee)
                            }
                        },
                        addValidationRule: function(e, r) {
                            try {
                                var t = $(this.el).data("api-validations") || [];
                                t.push({
                                    cb: e,
                                    message: r
                                }),
                                    $(this.el).data("api-validations", t)
                            } catch (l) {
                                error_handler(l, "libs_plp 12", arguments.callee)
                            }
                        },
                        removeValidationRule: function(e) {
                            try {
                                var r = $(this.el).data("api-validations") || [];
                                $(this.el).data("api-validations", _.without(r, {
                                    cb: e
                                }))
                            } catch (t) {
                                error_handler(t, "libs_plp 13", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Form = {
                    name: "Form",
                    initialize: function(r) {
                        try {
                            var t = $(this.el).data("api-swiper");
                            t && (t.on("slideChangeTransitionStart", function() {
                                try {
                                    e.Emmiter.emit(this, "before-step-change", {
                                        prevent: function() {
                                            try {
                                                console.error("Отмена перелистывания еще не работает")
                                            } catch (e) {
                                                error_handler(e, "libs_plp 3", arguments.callee)
                                            }
                                        }
                                            .bind(this)
                                    }, {
                                        previousIndex: t.previousIndex,
                                        activeIndex: t.activeIndex
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            }
                                .bind(this)),
                                t.on("slideChangeTransitionEnd", function() {
                                    try {
                                        e.Emmiter.emit(this, "step-change", null, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this))),
                                Object.defineProperty(this, "name", {
                                    get: function() {
                                        try {
                                            return r.data("api-name")
                                        } catch (e) {
                                            error_handler(e, "libs_plp 5", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "isQuiz", {
                                    value: r.data("api-isQuiz")
                                }),
                                Object.defineProperty(this, "isValid", {
                                    get: function() {
                                        try {
                                            return 0 === r.data("api-errors").length
                                        } catch (e) {
                                            error_handler(e, "libs_plp 6", arguments.callee)
                                        }
                                    }
                                }),
                                e.defineLazyProperty(this, "fields", function() {
                                    try {
                                        var t = [];
                                        return _.each(r.data("api-$fields"), function(r, l) {
                                            try {
                                                e.defineLazyProperty(t, l, function() {
                                                    try {
                                                        return e.Component.create($(r))
                                                    } catch (t) {
                                                        error_handler(t, "libs_plp 9", arguments.callee)
                                                    }
                                                }
                                                    .bind(this))
                                            } catch (a) {
                                                error_handler(a, "libs_plp 8", arguments.callee)
                                            }
                                        }
                                            .bind(this)),
                                            t
                                    } catch (l) {
                                        error_handler(l, "libs_plp 7", arguments.callee)
                                    }
                                }),
                                r.on("api-submit", function(r, t, l) {
                                    try {
                                        e.Emmiter.emit(this, "submit", null, {
                                            orderId: t,
                                            fields: l
                                        })
                                    } catch (a) {
                                        error_handler(a, "libs_plp 10", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (l) {
                            error_handler(l, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["before-submit", "submit", "before-step-change", "step-change"],
                    methods: {
                        recalculate: function() {
                            try {
                                $(this.el).trigger("input");
                            } catch (e) {
                                error_handler(e, "libs_plp 11", arguments.callee)
                            }
                        },
                        reset: function() {
                            try {
                                $(this.el).trigger("reset")
                            } catch (e) {
                                error_handler(e, "libs_plp 12", arguments.callee)
                            }
                        },
                        submit: function() {
                            try {
                                $(this.el).trigger("submit")
                            } catch (e) {
                                error_handler(e, "libs_plp 13", arguments.callee)
                            }
                        },
                        setName: function(e) {
                            try {
                                $(this.el).data("api-name", e.toString())
                            } catch (r) {
                                error_handler(r, "libs_plp 14", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Hover = {
                    name: "Hover",
                    initialize: function(r) {
                        try {
                            r.on("api-before-over", function() {
                                try {
                                    e.Emmiter.emit(this, "before-over")
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            }
                                .bind(this)),
                                r.on("api-over", function() {
                                    try {
                                        e.Emmiter.emit(this, "over")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 3", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("api-before-out", function() {
                                    try {
                                        e.Emmiter.emit(this, "before-out")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("api-out", function() {
                                    try {
                                        e.Emmiter.emit(this, "out")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["before-over", "over", "before-out", "out"],
                    methods: {}
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Page = {
                    name: "Page",
                    instance: null,
                    initialize: function() {
                        try {
                            Object.defineProperty(this, "id", {
                                value: creatium.page_id
                            }),
                                e.defineLazyProperty(this, "cart", function() {
                                    try {
                                        return e.Cart.create()
                                    } catch (r) {
                                        error_handler(r, "libs_plp 2", arguments.callee)
                                    }
                                }),
                                $(creatium).on("api-popup-show", function(r, t) {
                                    try {
                                        e.Emmiter.emit(this, "popup-show", null, {
                                            popup: e.Popup.create(t)
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 3", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                $(creatium).on("api-popup-hide", function(r, t) {
                                    try {
                                        e.Emmiter.emit(this, "popup-hide", null, {
                                            popup: e.Popup.create(t)
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                $(creatium).on("api-before-form-submit", function(r, t, l) {
                                    try {
                                        var a = e.Component.create(t)
                                            , i = l.map(function(e) {
                                            try {
                                                return e._key = _.uniqueId("field"),
                                                    {
                                                        name: e.name,
                                                        value: e.value,
                                                        uid: e.id,
                                                        _key: e._key
                                                    }
                                            } catch (r) {
                                                error_handler(r, "libs_plp 6", arguments.callee)
                                            }
                                        })
                                            , n = function(e) {
                                            try {
                                                e.fields.forEach(function(e) {
                                                    try {
                                                        "string" != typeof e.uid && (e.uid = "")
                                                    } catch (r) {
                                                        error_handler(r, "libs_plp 8", arguments.callee)
                                                    }
                                                })
                                            } catch (r) {
                                                error_handler(r, "libs_plp 7", arguments.callee)
                                            }
                                        }
                                            , c = function(e) {
                                            try {
                                                t.data("api-prevent", !0)
                                            } catch (r) {
                                                error_handler(r, "libs_plp 9", arguments.callee)
                                            }
                                        };
                                        e.Emmiter.emit(a, "before-submit", {
                                            intermediate: n,
                                            prevent: c
                                        }, {
                                            fields: i
                                        }),
                                            e.Emmiter.emit(this, "before-form-submit", {
                                                intermediate: n,
                                                isPrevented: t.data("api-prevent") === !0,
                                                prevent: c
                                            }, {
                                                form: a,
                                                fields: i
                                            });
                                        var o = _.clone(l);
                                        l.splice(0, l.length),
                                            i.forEach(function(e) {
                                                try {
                                                    if (e._key)
                                                        var r = _.find(o, {
                                                            _key: e._key
                                                        });
                                                    r ? (e.type = r.type,
                                                        e.required = r.required) : ("number" == typeof e.type ? e.type = "number" : e.type = "string",
                                                        e.required = !1),
                                                        l.push({
                                                            name: e.name,
                                                            value: e.value,
                                                            id: e.uid,
                                                            required: e.required,
                                                            type: e.type
                                                        })
                                                } catch (t) {
                                                    error_handler(t, "libs_plp 10", arguments.callee)
                                                }
                                            })
                                    } catch (s) {
                                        error_handler(s, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                $(creatium).on("api-form-submit", function(r, t, l, a) {
                                    try {
                                        e.Emmiter.emit(this, "form-submit", null, {
                                            form: e.Component.create(t),
                                            orderId: l,
                                            fields: a
                                        })
                                    } catch (i) {
                                        error_handler(i, "libs_plp 11", arguments.callee)
                                    }
                                }
                                    .bind(this))
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["before-form-submit", "form-submit", "popup-show", "popup-hide"],
                    methods: {
                        waitForAppear: function(e, r) {
                            try {
                                var t = document.querySelectorAll(e);
                                t && Array.prototype.forEach.call(t, r)
                            } catch (l) {
                                error_handler(l, "libs_plp 12", arguments.callee)
                            }
                        },
                        waitForLazy: function(e, r) {
                            try {
                                plp.lazy.add($(e), function(e) {
                                    try {
                                        r(e[0])
                                    } catch (t) {
                                        error_handler(t, "libs_plp 14", arguments.callee)
                                    }
                                }, 0)
                            } catch (t) {
                                error_handler(t, "libs_plp 13", arguments.callee)
                            }
                        },
                        lazy: function(e, r) {
                            try {
                                return this.waitForLazy(e, r)
                            } catch (t) {
                                error_handler(t, "libs_plp 15", arguments.callee)
                            }
                        },
                        scrollTo: function(e, r) {
                            try {
                                if ("string" == typeof e && (e = document.getElementById(e)),
                                    !(e instanceof Element))
                                    throw new Error("Unknown element");
                                creatium.scrollTo($(e), r)
                            } catch (t) {
                                error_handler(t, "libs_plp 16", arguments.callee)
                            }
                        },
                        scrollToTop: function() {
                            try {
                                creatium.scrollTo($(".area"))
                            } catch (e) {
                                error_handler(e, "libs_plp 17", arguments.callee)
                            }
                        },
                        getPopup: function(r) {
                            try {
                                var t = $(".modal").filter(function() {
                                    try {
                                        return $(this).attr("data-id") === r
                                    } catch (e) {
                                        error_handler(e, "libs_plp 19", arguments.callee)
                                    }
                                });
                                return t.length ? e.Popup.create(t) : null
                            } catch (l) {
                                error_handler(l, "libs_plp 18", arguments.callee)
                            }
                        },
                        getComponent: function(r) {
                            try {
                                if ("string" == typeof r) {
                                    var t = document.getElementById(r);
                                    if (!t)
                                        for (var l = creatium.async.cuts, a = 0; a < l.length; a++)
                                            if (!l[a].attached && null !== l[a].placeholder && 0 !== l[a].key.indexOf("svg") && (l[a].el || (l[a].el = $.parseHTML(l[a].html)[0]),
                                                t = l[a].el.querySelector("#" + r))) {
                                                creatium.lazy.trigger(l[a].placeholder);
                                                break
                                            }
                                } else if (r instanceof Element)
                                    var t = r;
                                else {
                                    if (!(r instanceof $ && r[0]instanceof Element))
                                        return null;
                                    var t = r[0]
                                }
                                return e.Component.create($(t))
                            } catch (i) {
                                error_handler(i, "libs_plp 20", arguments.callee)
                            }
                        },
                        getComponentsByClass: function(r, t) {
                            try {
                                t instanceof Element || (t = document);
                                var l = [];
                                return t.querySelectorAll("div[data-cut], ." + r).forEach(function(t) {
                                    try {
                                        var a = t.getAttribute("data-cut");
                                        if (a) {
                                            var i = _.find(creatium.async.cuts, {
                                                key: a
                                            });
                                            i.el || (i.el = $.parseHTML(i.html)[0]);
                                            var n = !1;
                                            i.el.querySelectorAll("." + r).forEach(function(r) {
                                                try {
                                                    var t = e.Page.instance.getComponent(r);
                                                    t && (l.push(t),
                                                        n = !0)
                                                } catch (a) {
                                                    error_handler(a, "libs_plp 23", arguments.callee)
                                                }
                                            }),
                                            n && creatium.lazy.trigger(i.placeholder)
                                        } else {
                                            var c = e.Page.instance.getComponent(t);
                                            c && l.push(c)
                                        }
                                    } catch (o) {
                                        error_handler(o, "libs_plp 22", arguments.callee)
                                    }
                                }),
                                    l
                            } catch (a) {
                                error_handler(a, "libs_plp 21", arguments.callee)
                            }
                        },
                        closeTopPopup: function() {
                            try {
                                creatium.modal.close()
                            } catch (e) {
                                error_handler(e, "libs_plp 24", arguments.callee)
                            }
                        },
                        closeAllPopups: function() {
                            try {
                                creatium.modal.closeAll()
                            } catch (e) {
                                error_handler(e, "libs_plp 25", arguments.callee)
                            }
                        },
                        showSuccessMessage: function(e, r) {
                            try {
                                creatium.msg_success(e, r)
                            } catch (t) {
                                error_handler(t, "libs_plp 26", arguments.callee)
                            }
                        },
                        showInformationMessage: function(e, r) {
                            try {
                                creatium.msg_info(e, r)
                            } catch (t) {
                                error_handler(t, "libs_plp 27", arguments.callee)
                            }
                        },
                        showErrorMessage: function(e, r) {
                            try {
                                creatium.msg_error(e, r)
                            } catch (t) {
                                error_handler(t, "libs_plp 28", arguments.callee)
                            }
                        },
                        createPortal: function(r) {
                            try {
                                return e.Portal.create(r)
                            } catch (t) {
                                error_handler(t, "libs_plp 29", arguments.callee)
                            }
                        }
                    },
                    create: function() {
                        try {
                            return e.Page.instance ? e.Page.instance : (e.Page.instance = e.factory([e.Emmiter, e.Page]),
                                e.Page.instance)
                        } catch (r) {
                            error_handler(r, "libs_plp 30", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Popup = {
                    name: "Popup",
                    initialize: function(r) {
                        try {
                            Object.defineProperty(this, "el", {
                                value: r[0]
                            }),
                                Object.defineProperty(this, "id", {
                                    value: this.el.getAttribute("data-id")
                                }),
                                r.on("before-show", function() {
                                    try {
                                        e.Emmiter.emit(this, "before-show", {
                                            prevent: function() {
                                                try {
                                                    $(this.el).data("api_prevent", !0)
                                                } catch (e) {
                                                    error_handler(e, "libs_plp 3", arguments.callee)
                                                }
                                            }
                                                .bind(this)
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 2", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("show", function() {
                                    try {
                                        e.Emmiter.emit(this, "show")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("before-hide", function() {
                                    try {
                                        e.Emmiter.emit(this, "before-hide", {
                                            prevent: function() {
                                                try {
                                                    $(this.el).data("api_prevent", !0)
                                                } catch (e) {
                                                    error_handler(e, "libs_plp 6", arguments.callee)
                                                }
                                            }
                                                .bind(this)
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                r.on("hide", function() {
                                    try {
                                        e.Emmiter.emit(this, "hide")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 7", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                Object.defineProperty(this, "isShown", {
                                    get: function() {
                                        try {
                                            return plp.modal.isOpen($(this.el))
                                        } catch (e) {
                                            error_handler(e, "libs_plp 8", arguments.callee)
                                        }
                                    }
                                        .bind(this)
                                })
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["show", "hide", "before-hide", "before-show"],
                    methods: {
                        getComponentsByClass: function(r) {
                            try {
                                return e.Page.instance.getComponentsByClass(r, this.el)
                            } catch (t) {
                                error_handler(t, "libs_plp 9", arguments.callee)
                            }
                        },
                        attach: function() {
                            try {} catch (e) {
                                error_handler(e, "libs_plp 10", arguments.callee)
                            }
                        },
                        show: function() {
                            try {
                                plp.modal.show($(this.el))
                            } catch (e) {
                                error_handler(e, "libs_plp 11", arguments.callee)
                            }
                        },
                        hide: function() {
                            try {
                                plp.modal.hide($(this.el))
                            } catch (e) {
                                error_handler(e, "libs_plp 12", arguments.callee)
                            }
                        }
                    },
                    create: function(r) {
                        try {
                            var t = r.data("api.Popup");
                            return t ? t : (t = e.factory([e.Emmiter, e.Popup], r),
                                r.data("api.Popup", t),
                                t)
                        } catch (l) {
                            error_handler(l, "libs_plp 13", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Portal = {
                    name: "Portal",
                    initialize: function(e) {
                        try {
                            Object.defineProperty(this, "el", {
                                value: e[0]
                            })
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: [],
                    methods: {},
                    create: function(r) {
                        try {
                            var t = $('<div class="cr-portal">')
                                , l = $(r).closest(".metahtml");
                            l.length && (t.addClass("metahtml"),
                                t.attr("id", l.children(".code").attr("id")));
                            var a = $(r).closest(".modal");
                            if (a.length)
                                t.appendTo("body > .area").css("z-index", 1060);
                            else {
                                var i = $(r).closest(".node.section");
                                i.length && t.appendTo("body > .area").css("z-index", 810)
                            }
                            return t.data("portal-parent", r.parentElement),
                                t.append(r),
                                e.factory([e.Emmiter, e.Portal], t)
                        } catch (n) {
                            error_handler(n, "libs_plp 2", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Section = {
                    name: "Section",
                    initialize: function(r) {
                        try {
                            r.on("fixation-change", function() {
                                try {
                                    e.Emmiter.emit(this, "sticky-change", null, {
                                        isStuck: this.isStuck
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            }
                                .bind(this)),
                                Object.defineProperty(this, "isSticky", {
                                    value: $(this.el).hasClass("fixation")
                                }),
                                Object.defineProperty(this, "isStuck", {
                                    get: function() {
                                        try {
                                            return this.el.classList.contains("fixed")
                                        } catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    }
                                })
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["sticky-change"]
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Slide = {
                    name: "Slide",
                    initialize: function(e, r) {
                        try {
                            Object.defineProperty(this, "slider", {
                                value: r
                            }),
                                Object.defineProperty(this, "el", {
                                    value: e[0]
                                }),
                                Object.defineProperty(this, "index", {
                                    value: e.index(".swiper-slide")
                                }),
                                Object.defineProperty(this, "isFirst", {
                                    value: 0 === this.index
                                }),
                                Object.defineProperty(this, "isLast", {
                                    value: this.index === this.slider.slides.length - 1
                                }),
                                Object.defineProperty(this, "isActive", {
                                    get: function() {
                                        try {
                                            return this.slider.activeIndex === this.index
                                        } catch (e) {
                                            error_handler(e, "libs_plp 2", arguments.callee)
                                        }
                                    }
                                })
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: [],
                    methods: {
                        slideTo: function() {
                            try {
                                return this.slider.slideTo(this.index)
                            } catch (e) {
                                error_handler(e, "libs_plp 3", arguments.callee)
                            }
                        },
                        getComponentsByClass: function(r) {
                            try {
                                return e.Page.instance.getComponentsByClass(r, this.el)
                            } catch (t) {
                                error_handler(t, "libs_plp 4", arguments.callee)
                            }
                        }
                    },
                    create: function(r, t) {
                        try {
                            var l = r.data("api.Slide");
                            return l ? l : (l = e.factory([e.Emmiter, e.Slide], r, t),
                                r.data("api.Slide", l),
                                l)
                        } catch (a) {
                            error_handler(a, "libs_plp 5", arguments.callee)
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Slider = {
                    name: "Slider",
                    initialize: function(r) {
                        try {
                            var t = $(this.el).data("api-swiper");
                            t.on("slideChangeTransitionStart", function() {
                                try {
                                    e.Emmiter.emit(this, "before-slide-change", {
                                        prevent: function() {
                                            try {
                                                console.error("Отмена перелистывания еще не работает")
                                            } catch (e) {
                                                error_handler(e, "libs_plp 3", arguments.callee)
                                            }
                                        }
                                            .bind(this)
                                    }, {
                                        previousIndex: t.previousIndex,
                                        activeIndex: t.activeIndex
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            }
                                .bind(this)),
                                t.on("slideChangeTransitionEnd", function() {
                                    try {
                                        e.Emmiter.emit(this, "slide-change", null, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                t.on("slideNextTransitionStart", function() {
                                    try {
                                        e.Emmiter.emit(this, "before-slide-next", {
                                            prevent: function() {
                                                try {
                                                    console.error("Отмена перелистывания еще не работает")
                                                } catch (e) {
                                                    error_handler(e, "libs_plp 6", arguments.callee)
                                                }
                                            }
                                                .bind(this)
                                        }, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 5", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                t.on("slideNextTransitionEnd", function() {
                                    try {
                                        e.Emmiter.emit(this, "slide-next", null, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 7", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                t.on("slidePrevTransitionStart", function() {
                                    try {
                                        e.Emmiter.emit(this, "before-slide-prev", {
                                            prevent: function() {
                                                try {
                                                    console.error("Отмена перелистывания еще не работает")
                                                } catch (e) {
                                                    error_handler(e, "libs_plp 9", arguments.callee)
                                                }
                                            }
                                                .bind(this)
                                        }, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 8", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                t.on("slidePrevTransitionEnd", function() {
                                    try {
                                        e.Emmiter.emit(this, "slide-prev", null, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 10", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                t.on("reachEnd", function() {
                                    try {
                                        e.Emmiter.emit(this, "reach-end", null, {
                                            previousIndex: t.previousIndex,
                                            activeIndex: t.activeIndex
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 11", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                e.defineLazyProperty(this, "_swiper", function() {
                                    try {
                                        return $(this.el).data("api-swiper")
                                    } catch (e) {
                                        error_handler(e, "libs_plp 12", arguments.callee)
                                    }
                                }),
                                e.defineLazyProperty(this, "slides", function() {
                                    try {
                                        var r = [];
                                        return _.each(this._swiper.slides, function(t, l) {
                                            try {
                                                e.defineLazyProperty(r, l, function() {
                                                    try {
                                                        return e.Slide.create($(t), this)
                                                    } catch (r) {
                                                        error_handler(r, "libs_plp 15", arguments.callee)
                                                    }
                                                }
                                                    .bind(this))
                                            } catch (a) {
                                                error_handler(a, "libs_plp 14", arguments.callee)
                                            }
                                        }
                                            .bind(this)),
                                            r
                                    } catch (t) {
                                        error_handler(t, "libs_plp 13", arguments.callee)
                                    }
                                }),
                                e.defineLazyProperty(this, "isLoop", function() {
                                    try {
                                        return !0
                                    } catch (e) {
                                        error_handler(e, "libs_plp 16", arguments.callee)
                                    }
                                }),
                                Object.defineProperty(this, "activeIndex", {
                                    get: function() {
                                        try {
                                            return this._swiper.activeIndex
                                        } catch (e) {
                                            error_handler(e, "libs_plp 17", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "isAnimating", {
                                    get: function() {
                                        try {
                                            return this._swiper.animating
                                        } catch (e) {
                                            error_handler(e, "libs_plp 18", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "isBeginning", {
                                    get: function() {
                                        try {
                                            return this._swiper.isBeginning
                                        } catch (e) {
                                            error_handler(e, "libs_plp 19", arguments.callee)
                                        }
                                    }
                                }),
                                Object.defineProperty(this, "isEnd", {
                                    get: function() {
                                        try {
                                            return this._swiper.isEnd
                                        } catch (e) {
                                            error_handler(e, "libs_plp 20", arguments.callee)
                                        }
                                    }
                                })
                        } catch (l) {
                            error_handler(l, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["before-slide-change", "slide-change", "before-slide-next", "slide-next", "before-slide-prev", "slide-prev", "reach-end"],
                    methods: {
                        slideTo: function(e) {
                            try {
                                return !(e < 0) && (!(e >= this.slides.length) && (e !== this.activeIndex && (this._swiper.slideTo(e),
                                    !0)))
                            } catch (r) {
                                error_handler(r, "libs_plp 21", arguments.callee)
                            }
                        },
                        slideNext: function() {
                            try {
                                return $(this.el).triggerHandler("slidenext"),
                                    this.isAnimating
                            } catch (e) {
                                error_handler(e, "libs_plp 22", arguments.callee)
                            }
                        },
                        slidePrev: function() {
                            try {
                                return $(this.el).triggerHandler("slideprev"),
                                    this.isAnimating
                            } catch (e) {
                                error_handler(e, "libs_plp 23", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        function(e) {
            try {
                e.Spoiler = {
                    name: "Spoiler",
                    initialize: function(r) {
                        try {
                            r.on("api-before-toggle", function() {
                                try {
                                    var t = function() {
                                        try {
                                            r.data("api-prevent", !0)
                                        } catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    };
                                    this.isCollapsed ? e.Emmiter.emit(this, "before-expand", {
                                        prevent: t
                                    }) : e.Emmiter.emit(this, "before-collapse", {
                                        prevent: t
                                    }),
                                        e.Emmiter.emit(this, "before-toggle", {
                                            prevent: t
                                        })
                                } catch (l) {
                                    error_handler(l, "libs_plp 2", arguments.callee)
                                }
                            }
                                .bind(this)),
                                r.on("api-toggle", function() {
                                    try {
                                        Object.defineProperty(this, "isCollapsed", {
                                            configurable: !0,
                                            value: !this.isCollapsed
                                        }),
                                            this.isCollapsed ? e.Emmiter.emit(this, "collapse") : e.Emmiter.emit(this, "expand"),
                                            e.Emmiter.emit(this, "toggle")
                                    } catch (r) {
                                        error_handler(r, "libs_plp 4", arguments.callee)
                                    }
                                }
                                    .bind(this)),
                                Object.defineProperty(this, "isCollapsed", {
                                    configurable: !0,
                                    value: r.data("api-isCollapsed")
                                })
                        } catch (t) {
                            error_handler(t, "libs_plp 1", arguments.callee)
                        }
                    },
                    events: ["before-collapse", "collapse", "before-expand", "expand", "before-toggle", "toggle"],
                    methods: {
                        collapse: function() {
                            try {
                                this.isCollapsed || $(this.el).triggerHandler("toggle")
                            } catch (e) {
                                error_handler(e, "libs_plp 5", arguments.callee)
                            }
                        },
                        expand: function() {
                            try {
                                this.isCollapsed && $(this.el).triggerHandler("toggle")
                            } catch (e) {
                                error_handler(e, "libs_plp 6", arguments.callee)
                            }
                        },
                        toggle: function() {
                            try {
                                $(this.el).triggerHandler("toggle")
                            } catch (e) {
                                error_handler(e, "libs_plp 7", arguments.callee)
                            }
                        }
                    }
                }
            } catch (r) {
                error_handler(r, "libs_plp 0", arguments.callee)
            }
        }(creatium.api.v1),
        creatium.cdn = {
            files: {},
            init: function() {
                try {
                    $(document.body).find(".component-js-fn").each(function() {
                        try {
                            var e = $(this).data("cdn") || [];
                            if (e.length)
                                return;
                            e.forEach(function(e) {
                                try {
                                    creatium.cdn.load(e, function() {
                                        try {} catch (e) {
                                            error_handler(e, "libs_plp 3", arguments.callee)
                                        }
                                    })
                                } catch (r) {
                                    error_handler(r, "libs_plp 2", arguments.callee)
                                }
                            })
                        } catch (r) {
                            error_handler(r, "libs_plp 1", arguments.callee)
                        }
                    })
                } catch (e) {
                    error_handler(e, "libs_plp 0", arguments.callee)
                }
            },
            load: function(e, r) {
                try {
                    creatium.cdn.files[e] ? creatium.cdn.files[e].loaded ? r() : creatium.cdn.files[e].callbacks.push(r) : (creatium.cdn.files[e] = {
                        loaded: !1,
                        callbacks: [r]
                    },
                        "css" === _.last(e.split(".")) ? creatium.cdn.loadStyle(e) : "js" === _.last(e.split(".")) ? creatium.cdn.loadScript(e) : console.error("CDN file should be .js or .css"))
                } catch (t) {
                    error_handler(t, "libs_plp 4", arguments.callee)
                }
            },
            loadStyle: function(e) {
                try {
                    var r = document.createElement("link");
                    r.setAttribute("type", "text/css"),
                        r.setAttribute("rel", "stylesheet"),
                        r.setAttribute("href", e),
                        document.head.appendChild(r),
                        setTimeout(function() {
                            try {
                                creatium.cdn.files[e].loaded = !0,
                                    creatium.cdn.files[e].callbacks.forEach(function(e) {
                                        try {
                                            e()
                                        } catch (r) {
                                            error_handler(r, "libs_plp 7", arguments.callee)
                                        }
                                    })
                            } catch (r) {
                                error_handler(r, "libs_plp 6", arguments.callee)
                            }
                        })
                } catch (t) {
                    error_handler(t, "libs_plp 5", arguments.callee)
                }
            },
            loadScript: function(e) {
                try {
                    var r = document.createElement("script");
                    r.onload = function() {
                        try {
                            creatium.cdn.files[e].loaded = !0,
                                creatium.cdn.files[e].callbacks.forEach(function(e) {
                                    try {
                                        e()
                                    } catch (r) {
                                        error_handler(r, "libs_plp 10", arguments.callee)
                                    }
                                })
                        } catch (r) {
                            error_handler(r, "libs_plp 9", arguments.callee)
                        }
                    }
                        ,
                        r.onerror = r.onload,
                        r.setAttribute("async", ""),
                        r.setAttribute("type", "text/javascript"),
                        r.setAttribute("src", e),
                        document.head.appendChild(r)
                } catch (t) {
                    error_handler(t, "libs_plp 8", arguments.callee)
                }
            }
        },
        $(function() {
            try {
                setTimeout(function() {
                    try {
                        $(".component-js-fn").each(function() {
                            try {
                                var e = window["_component_js_" + $(this).data("name")]
                                    , r = $(this).closest(".node")[0]
                                    , t = !!$(this).data("lazy")
                                    , l = $(this).data("cdn") || []
                                    , a = $(this).data("params");
                                l = l.map(function(e) {
                                    try {
                                        return e.trim()
                                    } catch (r) {
                                        error_handler(r, "libs_plp 14", arguments.callee)
                                    }
                                }).filter(function(e) {
                                    try {
                                        return e.length
                                    } catch (r) {
                                        error_handler(r, "libs_plp 15", arguments.callee)
                                    }
                                });
                                var i = function() {
                                    try {
                                        creatium.api(function(l) {
                                            try {
                                                var i = function() {
                                                    try {
                                                        try {
                                                            e(l, r, a)
                                                        } catch (t) {
                                                            console.error("Component JS error", this, t)
                                                        }
                                                    } catch (i) {
                                                        error_handler(i, "libs_plp 18", arguments.callee)
                                                    }
                                                };
                                                t ? l.waitForLazy(r, i) : i()
                                            } catch (n) {
                                                error_handler(n, "libs_plp 17", arguments.callee)
                                            }
                                        })
                                    } catch (l) {
                                        error_handler(l, "libs_plp 16", arguments.callee)
                                    }
                                };
                                l.length ? l.forEach(function(e) {
                                    try {
                                        creatium.cdn.load(e, function() {
                                            try {
                                                var e = !0;
                                                l.forEach(function(r) {
                                                    try {
                                                        creatium.cdn.files[r].loaded === !1 && (e = !1)
                                                    } catch (t) {
                                                        error_handler(t, "libs_plp 21", arguments.callee)
                                                    }
                                                }),
                                                e === !0 && i()
                                            } catch (r) {
                                                error_handler(r, "libs_plp 20", arguments.callee)
                                            }
                                        })
                                    } catch (r) {
                                        error_handler(r, "libs_plp 19", arguments.callee)
                                    }
                                }) : i()
                            } catch (n) {
                                error_handler(n, "libs_plp 13", arguments.callee)
                            }
                        })
                    } catch (e) {
                        error_handler(e, "libs_plp 12", arguments.callee)
                    }
                }, 10)
            } catch (e) {
                error_handler(e, "libs_plp 11", arguments.callee)
            }
        })
}($);
